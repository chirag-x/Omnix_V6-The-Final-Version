from core.task.models import create_task_step, create_task_plan

# Debug the circular dependency test - correct approach
print("Creating steps for circular dependency test...")

# First, create all steps to get their IDs
step1 = create_task_step(0, "Step 1", "Intent 1", "cap1")
step2 = create_task_step(1, "Step 2", "Intent 2", "cap2")
step3 = create_task_step(2, "Step 3", "Intent 3", "cap3")
step4 = create_task_step(3, "Step 4", "Intent 4", "cap4")

print(f"Original step IDs:")
print(f"  Step 1: {step1.step_id}")
print(f"  Step 2: {step2.step_id}")
print(f"  Step 3: {step3.step_id}")
print(f"  Step 4: {step4.step_id}")

# Now create the circular dependency steps using the actual IDs
step1_circular = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset([step4.step_id]))
step2_circular = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1.step_id]))
step3_circular = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([step2.step_id]))
step4_circular = create_task_step(3, "Step 4", "Intent 4", "cap4", dependencies=frozenset([step3.step_id]))

print(f"\nCircular dependency step IDs:")
print(f"  Step 1: {step1_circular.step_id} (deps: {step1_circular.dependencies})")
print(f"  Step 2: {step2_circular.step_id} (deps: {step2_circular.dependencies})")
print(f"  Step 3: {step3_circular.step_id} (deps: {step3_circular.dependencies})")
print(f"  Step 4: {step4_circular.step_id} (deps: {step4_circular.dependencies})")

# Create plan with these steps
plan = create_task_plan("Test goal", (step1_circular, step2_circular, step3_circular, step4_circular))

print(f"\nPlan steps:")
for i, step in enumerate(plan.steps):
    print(f"  Step {i}: {step.step_id} (deps: {step.dependencies})")

print(f"\nHas circular dependency: {plan.has_circular_dependency()}")

# Let's trace the algorithm manually to see what's happening
print("\nTracing has_circular_dependency algorithm:")
visited = set()
rec_stack = set()

def has_cycle(step_id):
    step = plan.get_step_by_id(step_id)
    if not step:
        print(f"  Step {step_id} not found in plan!")
        return False

    print(f"  Visiting step {step.step_id} (ID: {step_id})")

    if step_id in rec_stack:
        print(f"    CYCLE DETECTED! {step_id} already in rec_stack")
        return True

    if step_id in visited:
        print(f"    Step {step_id} already visited, skipping")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"    Added {step_id} to visited and rec_stack")

    # Check all dependencies
    for dep_id in step.dependencies:
        print(f"    Checking dependency {dep_id}")
        if has_cycle(dep_id):
            return True

    rec_stack.remove(step_id)
    print(f"    Removed {step_id} from rec_stack")
    return False

# Check each step
print("\nChecking each step:")
for step in plan.steps:
    if step.step_id not in visited:
        print(f"Starting check from step {step.step_id}")
        if has_cycle(step.step_id):
            print("Cycle found!")
            break
else:
    print("No cycle found")