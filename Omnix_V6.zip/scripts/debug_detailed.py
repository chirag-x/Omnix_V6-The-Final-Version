from core.task.models import create_task_step, create_task_plan

print("=== Detailed Debug ===")

# Create steps in reverse order so we can reference the correct IDs
# We'll create them all first to get their IDs, then recreate with proper deps

# First pass: create steps to get their IDs for the circular dependency
temp_step1 = create_task_step(0, "Step 1", "Intent 1", "cap1")
temp_step2 = create_task_step(1, "Step 2", "Intent 2", "cap2")
temp_step3 = create_task_step(2, "Step 3", "Intent 3", "cap3")
temp_step4 = create_task_step(3, "Step 4", "Intent 4", "cap4")

print(f"Temp step IDs:")
print(f"  temp_step1: {temp_step1.step_id}")
print(f"  temp_step2: {temp_step2.step_id}")
print(f"  temp_step3: {temp_step3.step_id}")
print(f"  temp_step4: {temp_step4.step_id}")

# Second pass: create the actual steps with correct dependencies
# For circle 1->2->3->4->1:
# Step 1 should depend on Step 4's ID (temp_step4.step_id)
# Step 2 should depend on Step 1's ID (temp_step1.step_id)
# Step 3 should depend on Step 2's ID (temp_step2.step_id)
# Step 4 should depend on Step 3's ID (temp_step3.step_id)
step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset([temp_step4.step_id]))
step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([temp_step1.step_id]))
step3 = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([temp_step2.step_id]))
step4 = create_task_step(3, "Step 4", "Intent 4", "cap4", dependencies=frozenset([temp_step3.step_id]))

print(f"\nActual steps:")
print(f"  step1: {step1.step_id} -> deps: {list(step1.dependencies)[0]} (should be temp_step4)")
print(f"  step2: {step2.step_id} -> deps: {list(step2.dependencies)[0]} (should be temp_step1)")
print(f"  step3: {step3.step_id} -> deps: {list(step3.dependencies)[0]} (should be temp_step2)")
print(f"  step4: {step4.step_id} -> deps: {list(step4.dependencies)[0]} (should be temp_step3)")

# Create plan
plan = create_task_plan("Test goal", (step1, step2, step3, step4))

print(f"\nPlan steps:")
for i, s in enumerate(plan.steps):
    print(f"  [{i}] {s.step_id} -> deps: {list(s.dependencies)[0] if s.dependencies else 'None'}")

# Manual trace of has_circular_dependency
print(f"\n=== Tracing has_circular_dependency ===")

visited = set()
rec_stack = set()

def has_cycle(step_id):
    print(f"  has_cycle called with step_id: {step_id}")
    step = plan.get_step_by_id(step_id)
    if not step:
        print(f"    ERROR: get_step_by_id({step_id}) returned None!")
        print(f"    Available steps in plan: {[s.step_id for s in plan.steps]}")
        return False

    print(f"    Found step: {step.step_id}")

    if step_id in rec_stack:
        print(f"    CYCLE DETECTED! {step_id} in rec_stack")
        return True

    if step_id in visited:
        print(f"    Already visited {step_id}, skipping")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"    Added {step_id} to visited and rec_stack")

    # Check all dependencies
    print(f"    Checking dependencies: {step.dependencies}")
    for dep_id in step.dependencies:
        print(f"      Checking dependency {dep_id}")
        result = has_cycle(dep_id)
        print(f"      has_cycle({dep_id}) returned {result}")
        if result:
            return True

    rec_stack.remove(step_id)
    print(f"    Removed {step_id} from rec_stack")
    return False

# Check each step
print(f"\nChecking each step for cycles:")
for step in plan.steps:
    if step.step_id not in visited:
        print(f"Starting check from step {step.step_id}")
        if has_cycle(step.step_id):
            print("CYCLE FOUND!")
            break
else:
    print("No cycle found in any step check")

result = plan.has_circular_dependency()
print(f"\nFinal result from plan.has_circular_dependency(): {result}")