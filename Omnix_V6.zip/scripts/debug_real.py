from core.task.models import create_task_step, create_task_plan

# Let's manually create the exact same steps as in the test and see what happens
print("=== Creating steps exactly as in test ===")

# No circular dependency part
step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset())
step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1.step_id]))
plan1 = create_task_plan("Test goal", (step1, step2))
print(f"No circular dependency result: {plan1.has_circular_dependency()}")  # Should be False

print("\n=== Circular dependency part ===")
# Create all steps first to get their IDs
step1_temp = create_task_step(0, "Step 1", "Intent 1", "cap1")
step2_temp = create_task_step(1, "Step 2", "Intent 2", "cap2")
step3_temp = create_task_step(2, "Step 3", "Intent 3", "cap3")
step4_temp = create_task_step(3, "Step 4", "Intent 4", "cap4")

print(f"Temp step IDs:")
print(f"  step1_temp: {step1_temp.step_id}")
print(f"  step2_temp: {step2_temp.step_id}")
print(f"  step3_temp: {step3_temp.step_id}")
print(f"  step4_temp: {step4_temp.step_id}")

# Now create steps with proper dependencies for circular dependency: 1->2->3->4->1
step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset([step4_temp.step_id]))
step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1_temp.step_id]))
step3 = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([step2_temp.step_id]))
step4 = create_task_step(3, "Step 4", "Intent 4", "cap4", dependencies=frozenset([step3_temp.step_id]))

print(f"\nActual step IDs with dependencies:")
print(f"  step1: {step1.step_id} -> deps: {step1.dependencies}")
print(f"  step2: {step2.step_id} -> deps: {step2.dependencies}")
print(f"  step3: {step3.step_id} -> deps: {step3.dependencies}")
print(f"  step4: {step4.step_id} -> deps: {step4.dependencies}")

# Verify the dependencies are correct
print(f"\nVerification:")
print(f"  step1 depends on step4_temp: {list(step1.dependencies)[0] == step4_temp.step_id}")
print(f"  step2 depends on step1_temp: {list(step2.dependencies)[0] == step1_temp.step_id}")
print(f"  step3 depends on step2_temp: {list(step3.dependencies)[0] == step2_temp.step_id}")
print(f"  step4 depends on step3_temp: {list(step4.dependencies)[0] == step3_temp.step_id}")

plan2 = create_task_plan("Test goal", (step1, step2, step3, step4))
result = plan2.has_circular_dependency()
print(f"\nCircular dependency result: {result}")  # Should be True

print(f"\nPlan steps in plan2:")
for i, s in enumerate(plan2.steps):
    print(f"  [{i}] {s.step_id} -> deps: {s.dependencies}")

# Let's trace the has_circular_dependency method manually
print(f"\n=== Tracing has_circular_dependency ===")
visited = set()
rec_stack = set()

def has_cycle(step_id):
    print(f"  Checking step_id: {step_id}")
    step = plan2.get_step_by_id(step_id)
    if not step:
        print(f"    Step not found in plan!")
        return False

    print(f"    Found step: {step.step_id}")

    if step_id in rec_stack:
        print(f"    CYCLE DETECTED! {step_id} in rec_stack")
        return True

    if step_id in visited:
        print(f"    Already visited, skipping")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"    Added to visited and rec_stack")

    # Check all dependencies
    for dep_id in step.dependencies:
        print(f"    Checking dependency: {dep_id}")
        if has_cycle(dep_id):
            return True

    rec_stack.remove(step_id)
    print(f"    Removed from rec_stack")
    return False

# Check each step
print(f"Checking each step for cycles:")
for step in plan2.steps:
    if step.step_id not in visited:
        print(f"Starting check from step {step.step_id}")
        if has_cycle(step.step_id):
            print("CYCLE FOUND!")
            break
else:
    print("No cycle found")