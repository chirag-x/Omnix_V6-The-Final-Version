from core.task.models import create_task_step, create_task_plan

# Debug the circular dependency test
print("Creating steps for circular dependency test...")

# Create steps in order so they reference each other correctly
step1 = create_task_step(0, "Step 1", "Intent 1", "cap1")  # Will update deps after step4 created
print(f"Step 1 ID: {step1.step_id}")

step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1.step_id]))
print(f"Step 2 ID: {step2.step_id}")
print(f"Step 2 dependencies: {step2.dependencies}")

step3 = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([step2.step_id]))
print(f"Step 3 ID: {step3.step_id}")
print(f"Step 3 dependencies: {step3.dependencies}")

step4 = create_task_step(3, "Step 4", "Intent 4", "cap4", dependencies=frozenset([step3.step_id]))
print(f"Step 4 ID: {step4.step_id}")
print(f"Step 4 dependencies: {step4.dependencies}")

# Now update step1 to depend on step4 to close the circle: 1 -> 2 -> 3 -> 4 -> 1
step1_updated = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset([step4.step_id]))
print(f"Updated Step 1 ID: {step1_updated.step_id}")
print(f"Updated Step 1 dependencies: {step1_updated.dependencies}")

plan = create_task_plan("Test goal", (step1_updated, step2, step3, step4))
print(f"Plan ID: {plan.plan_id}")
print(f"Plan steps: {[s.step_id for s in plan.steps]}")

# Check each step's dependencies in the plan
for i, step in enumerate(plan.steps):
    print(f"Step {i} ({step.step_id}): dependencies = {step.dependencies}")

print(f"Has circular dependency: {plan.has_circular_dependency()}")

# Let's also manually trace what the algorithm should see
print("\nManual trace:")
visited = set()
rec_stack = set()

def has_cycle(step_id):
    step = plan.get_step_by_id(step_id)
    if not step:
        print(f"Step {step_id} not found!")
        return False

    print(f"Visiting step {step_id}")

    if step_id in rec_stack:
        print(f"Cycle detected! {step_id} in rec_stack")
        return True

    if step_id in visited:
        print(f"Step {step_id} already visited, skipping")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"Added {step_id} to visited and rec_stack")

    # Check all dependencies
    for dep_id in step.dependencies:
        print(f"Checking dependency {dep_id} of step {step_id}")
        if has_cycle(dep_id):
            return True

    rec_stack.remove(step_id)
    print(f"Removed {step_id} from rec_stack")
    return False

# Check each step
print("\nChecking each step for cycles:")
for step in plan.steps:
    if step.step_id not in visited:
        print(f"\nStarting check from step {step.step_id}")
        if has_cycle(step.step_id):
            print("Cycle found!")
            break
else:
    print("\nNo cycle found")