from core.task.models import create_task_step, create_task_plan

# Recreate the exact scenario from the test
s1 = create_task_step(0, "Step 1", "Intent 1", "cap1")
s2 = create_task_step(1, "Step 2", "Intent 2", "cap2")
s3 = create_task_step(2, "Step 3", "Intent 3", "cap3")
s4 = create_task_step(3, "Step 4", "Intent 4", "cap4")

step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset([s2.step_id]))  # Step 1 -> Step 2
step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([s3.step_id]))  # Step 2 -> Step 3
step3 = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([s4.step_id]))  # Step 3 -> Step 4
step4 = create_task_step(3, "Step 4", "Intent 4", "cap4", dependencies=frozenset([s1.step_id]))  # Step 4 -> Step 1

plan2 = create_task_plan("Test goal", (step1, step2, step3, step4))

print("Plan steps:")
for i, step in enumerate(plan2.steps):
    print(f"  [{i}] {step.step_id} -> deps: {list(step.dependencies)[0] if step.dependencies else 'None'}")

# Now let's manually trace the EXACT algorithm from has_circular_dependency
print("\n=== Tracing EXACT algorithm ===")

visited = set()
rec_stack = set()

def has_cycle(step_id: str) -> bool:
    print(f"has_cycle('{step_id}') called")
    step = plan2.get_step_by_id(step_id)
    if not step:
        print(f"  ERROR: get_step_by_id('{step_id}') returned None!")
        return False

    print(f"  Found step: {step.step_id}")

    if step_id in rec_stack:
        print(f"  CYCLE DETECTED! {step_id} in rec_stack")
        return True

    if step_id in visited:
        print(f"  Already visited {step_id}, returning False")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"  Added {step_id} to visited and rec_stack")

    # Check all dependencies
    print(f"  Checking dependencies: {step.dependencies}")
    for dep_id in step.dependencies:
        print(f"    Checking dependency {dep_id}")
        if has_cycle(dep_id):
            return True

    rec_stack.remove(step_id)
    print(f"  Removed {step_id} from rec_stack")
    return False

# Check each step (EXACT code from the method)
print(f"\n=== Checking each step ===")
for step in plan2.steps:
    print(f"\nChecking step {step.step_id}")
    if step.step_id not in visited:
        print(f"  {step.step_id} not in visited, calling has_cycle")
        if has_cycle(step.step_id):
            print("CYCLE FOUND in has_cycle!")
            break
    else:
        print(f"  {step.step_id} already in visited, skipping")
else:
    print("\nFinished checking all steps, no cycle found")

result = plan2.has_circular_dependency()
print(f"\nFinal result: {result}")