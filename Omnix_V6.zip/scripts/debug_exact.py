from core.task.models import create_task_step, create_task_plan

print("=== Running exact test code ===")

# No circular dependency
step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset())
step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1.step_id]))
plan1 = create_task_plan("Test goal", (step1, step2))
result1 = plan1.has_circular_dependency()
print(f"No circular dependency: {result1} (should be False)")
assert result1 == False, "First assertion failed"

# Circular dependency: 1 -> 2 -> 3 -> 4 -> 1
# To create this, we need:
# Step 1 depends on Step 4
# Step 2 depends on Step 1
# Step 3 depends on Step 2
# Step 4 depends on Step 3

# Create all steps first
step1_orig = create_task_step(0, "Step 1", "Intent 1", "cap1")
step2_orig = create_task_step(1, "Step 2", "Intent 2", "cap2")
step3_orig = create_task_step(2, "Step 3", "Intent 3", "cap3")
step4_orig = create_task_step(3, "Step 4", "Intent 4", "cap4")

print(f"\nOriginal step IDs:")
print(f"  step1_orig: {step1_orig.step_id}")
print(f"  step2_orig: {step2_orig.step_id}")
print(f"  step3_orig: {step3_orig.step_id}")
print(f"  step4_orig: {step4_orig.step_id}")

# Now recreate them with the correct dependencies for circular dependency
# Using the actual step IDs from above
step1_with_deps = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset([step4_orig.step_id]))
step2_with_deps = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1_orig.step_id]))
step3_with_deps = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([step2_orig.step_id]))
step4_with_deps = create_task_step(3, "Step 4", "Intent 4", "cap4", dependencies=frozenset([step3_orig.step_id]))

print(f"\nStep with dependencies:")
print(f"  step1_with_deps: {step1_with_deps.step_id} -> deps: {list(step1_with_deps.dependencies)[0]} (should be step4_orig)")
print(f"  step2_with_deps: {step2_with_deps.step_id} -> deps: {list(step2_with_deps.dependencies)[0]} (should be step1_orig)")
print(f"  step3_with_deps: {step3_with_deps.step_id} -> deps: {list(step3_with_deps.dependencies)[0]} (should be step2_orig)")
print(f"  step4_with_deps: {step4_with_deps.step_id} -> deps: {list(step4_with_deps.dependencies)[0]} (should be step3_orig)")

# Verify
assert list(step1_with_deps.dependencies)[0] == step4_orig.step_id, "step1 dep mismatch"
assert list(step2_with_deps.dependencies)[0] == step1_orig.step_id, "step2 dep mismatch"
assert list(step3_with_deps.dependencies)[0] == step2_orig.step_id, "step3 dep mismatch"
assert list(step4_with_deps.dependencies)[0] == step3_orig.step_id, "step4 dep mismatch"

plan2 = create_task_plan("Test goal", (step1_with_deps, step2_with_deps, step3_with_deps, step4_with_deps))
result2 = plan2.has_circular_dependency()
print(f"\nCircular dependency: {result2} (should be True)")

print(f"\nPlan2 steps:")
for i, step in enumerate(plan2.steps):
    print(f"  [{i}] {step.step_id} -> deps: {step.dependencies}")

# Manual trace of the algorithm
print(f"\n=== Manual trace of algorithm ===")
visited = set()
rec_stack = set()

def has_cycle(step_id):
    print(f"  Checking step_id: {step_id}")
    step = plan2.get_step_by_id(step_id)
    if not step:
        print(f"    ERROR: Step {step_id} not found in plan!")
        return False

    print(f"    Found step: {step.step_id}")

    if step_id in rec_stack:
        print(f"    CYCLE DETECTED! {step_id} in rec_stack")
        return True

    if step_id in visited:
        print(f"    Already visited, skipping")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"    Added to visited and rec_stack")

    # Check all dependencies
    for dep_id in step.dependencies:
        print(f"    Checking dependency: {dep_id}")
        if has_cycle(dep_id):
            return True

    rec_stack.remove(step_id)
    print(f"    Removed from rec_stack")
    return False

# Check each step
print(f"Checking each step for cycles:")
for step in plan2.steps:
    if step.step_id not in visited:
        print(f"Starting check from step {step.step_id}")
        if has_cycle(step.step_id):
            print("CYCLE FOUND!")
            break
else:
    print("No cycle found")

print(f"\nFinal result: {result2}")
assert result2 == True, "Second assertion failed"
print("All tests passed!")