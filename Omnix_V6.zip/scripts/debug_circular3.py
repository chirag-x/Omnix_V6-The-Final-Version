from core.task.models import create_task_step, create_task_plan

# Debug the circular dependency test - correct approach
print("Creating steps for circular dependency test...")

# We need to create steps where each step's dependency is the NEXT step's ID
# For circle 1->2->3->4->1:
# Step 1 should depend on Step 4's ID
# Step 2 should depend on Step 1's ID
# Step 3 should depend on Step 2's ID
# Step 4 should depend on Step 3's ID

# Since we don't know the IDs upfront, we need to create them in a way that
# we can reference the correct IDs

# Approach: Create steps in reverse order so we know the dependency IDs
# Actually, let's just create them and then recreate with correct dependencies

# First pass: create steps to get their IDs
print("First pass - getting IDs:")
s1 = create_task_step(0, "Step 1", "Intent 1", "cap1")
s2 = create_task_step(1, "Step 2", "Intent 2", "cap2")
s3 = create_task_step(2, "Step 3", "Intent 3", "cap3")
s4 = create_task_step(3, "Step 4", "Intent 4", "cap4")

print(f"Step 1 ID: {s1.step_id}")
print(f"Step 2 ID: {s2.step_id}")
print(f"Step 3 ID: {s3.step_id}")
print(f"Step 4 ID: {s4.step_id}")

# For circular dependency 1->2->3->4->1:
# Step 1 depends on Step 4
# Step 2 depends on Step 1
# Step 3 depends on Step 2
# Step 4 depends on Step 3

step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset([s4.step_id]))
step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([s1.step_id]))
step3 = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([s2.step_id]))
step4 = create_task_step(3, "Step 4", "Intent 4", "cap4", dependencies=frozenset([s3.step_id]))

print(f"\nAfter setting dependencies:")
print(f"Step 1: {step1.step_id} -> depends on {list(step1.dependencies)[0]}")
print(f"Step 2: {step2.step_id} -> depends on {list(step2.dependencies)[0]}")
print(f"Step 3: {step3.step_id} -> depends on {list(step3.dependencies)[0]}")
print(f"Step 4: {step4.step_id} -> depends on {list(step4.dependencies)[0]}")

# Verify the dependencies point to the right steps
dep1_id = list(step1.dependencies)[0]
dep2_id = list(step2.dependencies)[0]
dep3_id = list(step3.dependencies)[0]
dep4_id = list(step4.dependencies)[0]

print(f"\nVerification:")
print(f"Step 1 depends on ID: {dep1_id} (should be Step 4's ID: {s4.step_id}) -> Match: {dep1_id == s4.step_id}")
print(f"Step 2 depends on ID: {dep2_id} (should be Step 1's ID: {s1.step_id}) -> Match: {dep2_id == s1.step_id}")
print(f"Step 3 depends on ID: {dep3_id} (should be Step 2's ID: {s2.step_id}) -> Match: {dep3_id == s2.step_id}")
print(f"Step 4 depends on ID: {dep4_id} (should be Step 3's ID: {s3.step_id}) -> Match: {dep4_id == s3.step_id}")

# Create the plan
plan = create_task_plan("Test goal", (step1, step2, step3, step4))

print(f"\nPlan steps in order:")
for i, step in enumerate(plan.steps):
    dep_list = list(step.dependencies)
    dep_str = dep_list[0] if dep_list else "none"
    print(f"  [{i}] {step.step_id} -> depends on {dep_str}")

print(f"\nHas circular dependency: {plan.has_circular_dependency()}")

# Let's trace the algorithm
print("\nTracing algorithm:")
visited = set()
rec_stack = set()

def has_cycle(step_id):
    step = plan.get_step_by_id(step_id)
    if not step:
        print(f"  Step {step_id} not found!")
        return False

    print(f"  Visiting {step.step_id}")

    if step_id in rec_stack:
        print(f"    CYCLE! {step_id} in rec_stack")
        return True

    if step_id in visited:
        print(f"    Already visited {step_id}")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"    Added {step_id} to visited/rec_stack")

    for dep_id in step.dependencies:
        print(f"    Checking dependency {dep_id}")
        if has_cycle(dep_id):
            return True

    rec_stack.remove(step_id)
    print(f"    Removed {step_id} from rec_stack")
    return False

print("\nChecking each step:")
for step in plan.steps:
    if step.step_id not in visited:
        print(f"Starting from {step.step_id}")
        if has_cycle(step.step_id):
            print("CYCLE FOUND!")
            break
else:
    print("No cycle found")