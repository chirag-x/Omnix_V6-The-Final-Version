"""
Tests for Stage 21: Integration with OmnixEngine
"""

from unittest.mock import Mock, patch, MagicMock
import pytest
from core.omnix_engine import OmnixEngine
from core.task.executor import TaskExecutor
from core.task.models import TaskStatus


def test_omnix_engine_has_task_executor_when_available():
    """Test that OmnixEngine has task_executor attribute when TaskExecutor builds successfully"""
    with patch('core.task.executor.TaskExecutor') as mock_task_executor_class, \
         patch('core.omnix_engine.OmnixConfig') as mock_config_class, \
         patch('ai.intent.interpreter.LLMIntentInterpreter') as mock_interpreter_class, \
         patch('ai.intent.specs.build_default_registry') as mock_build_registry, \
         patch('ai.brain.deterministic.DeterministicPlanner') as mock_planner_class, \
         patch('core.orchestration.verifier.DefaultStepVerifier') as mock_step_verifier_class, \
         patch('core.orchestration.verifier.DefaultGoalVerifier') as mock_goal_verifier_class, \
         patch('core.orchestration.recovery.DefaultRecoveryEngine') as mock_recovery_engine_class, \
         patch('core.orchestration.observation.CapabilityResultObservationProvider') as mock_obs_provider_class, \
         patch('core.orchestration.agent.AgentPolicy') as mock_policy_class, \
         patch('core.omnix_engine.OmnixEngine._build_vision_target_provider') as mock_build_vision, \
         patch('core.omnix_engine.OmnixEngine._build_multi_step_coordinator') as mock_build_coordinator, \
         patch('core.omnix_engine.OmnixEngine._build_agent_observability_sink') as mock_build_sink, \
         patch('core.omnix_engine.OmnixEngine._build_progress_broadcaster') as mock_build_broadcaster, \
         patch('core.omnix_engine.OmnixEngine._build_app_dispatcher') as mock_build_dispatcher, \
         patch('core.omnix_engine.OmnixEngine._build_task_event_publisher') as mock_build_publisher:
        mock_task_executor_instance = Mock(spec=TaskExecutor)
        mock_task_executor_class.return_value = mock_task_executor_instance
        mock_config_instance = Mock()
        mock_config_class.return_value = mock_config_instance
        mock_config_instance.vision_confidence_threshold = 0.5
        mock_config_instance.default_action_timeout_s = 30.0
        mock_config_instance.screen_width = 1920
        mock_config_instance.screen_height = 1080
        mock_config_instance.inactivity_timeout_s = 30.0
        # FIX: Properly mock config for LLM provider resolution
        mock_extra = Mock()
        mock_extra.get.return_value = "mock"
        mock_config_instance.extra = mock_extra
        mock_interpreter_instance = Mock()
        mock_interpreter_class.return_value = mock_interpreter_instance
        mock_registry_instance = Mock()
        mock_build_registry.return_value = mock_registry_instance
        mock_planner_instance = Mock()
        mock_planner_class.return_value = mock_planner_instance
        mock_step_verifier_instance = Mock()
        mock_step_verifier_class.return_value = mock_step_verifier_instance
        mock_goal_verifier_instance = Mock()
        mock_goal_verifier_class.return_value = mock_goal_verifier_instance
        mock_recovery_engine_instance = Mock()
        mock_recovery_engine_class.return_value = mock_recovery_engine_instance
        mock_obs_provider_instance = Mock()
        mock_obs_provider_class.return_value = mock_obs_provider_instance
        mock_policy_instance = Mock()
        mock_policy_class.return_value = mock_policy_instance
        mock_vision_provider_instance = Mock()
        mock_build_vision.return_value = mock_vision_provider_instance
        mock_coordinator_instance = Mock()
        mock_build_coordinator.return_value = mock_coordinator_instance
        mock_sink_instance = Mock()
        mock_build_sink.return_value = mock_sink_instance
        mock_broadcaster_instance = Mock()
        mock_build_broadcaster.return_value = mock_broadcaster_instance
        mock_dispatcher_instance = Mock()
        mock_build_dispatcher.return_value = mock_dispatcher_instance
        mock_publisher_func = Mock()
        mock_build_publisher.return_value = mock_publisher_func

        engine = OmnixEngine(mock_config_instance)
        # Build the pipeline to trigger TaskExecutor construction
        pipeline = engine._build_pipeline()

        # Verify that we got a pipeline back (not None)
        assert pipeline is not None

        # Verify TaskExecutor was instantiated
        mock_task_executor_class.assert_called_once()
        # Verify engine has the task_executor attribute
        assert hasattr(engine, 'task_executor')
        assert engine.task_executor == mock_task_executor_instance


def test_omnix_engine_task_executor_none_when_build_fails():
    """Test that OmnixEngine.task_executor is None when TaskExecutor build fails"""
    with patch('core.task.executor.TaskExecutor') as mock_task_executor_class, \
         patch('core.omnix_engine.OmnixConfig') as mock_config_class:
        mock_task_executor_class.side_effect = Exception("Build failed")
        mock_config_instance = Mock()
        mock_config_class.return_value = mock_config_instance

        engine = OmnixEngine(mock_config_instance)
        # Build the pipeline to trigger TaskExecutor construction attempt
        engine._build_pipeline()

        # Verify engine has the task_executor attribute set to None
        assert hasattr(engine, 'task_executor')
        assert engine.task_executor is None


def test_omnix_engine_uses_task_executor_in_agent_when_available():
    """Test that OmnixEngine uses TaskExecutor in Agent when available"""
    with patch('core.task.executor.TaskExecutor') as mock_task_executor_class, \
         patch('core.orchestration.Agent') as mock_agent_class, \
         patch('core.omnix_engine.OmnixEngine._resolve_llm_provider') as mock_resolve_llm, \
         patch('ai.intent.interpreter.LLMIntentInterpreter') as mock_interpreter_class, \
         patch('ai.intent.specs.build_default_registry') as mock_build_registry, \
         patch('ai.brain.deterministic.DeterministicPlanner') as mock_planner_class, \
         patch('core.orchestration.verifier.DefaultStepVerifier') as mock_step_verifier_class, \
         patch('core.orchestration.verifier.DefaultGoalVerifier') as mock_goal_verifier_class, \
         patch('core.orchestration.recovery.DefaultRecoveryEngine') as mock_recovery_engine_class, \
         patch('core.orchestration.observation.CapabilityResultObservationProvider') as mock_obs_provider_class, \
         patch('core.orchestration.agent.AgentPolicy') as mock_policy_class, \
         patch('core.omnix_engine.OmnixEngine._build_vision_target_provider') as mock_build_vision, \
         patch('core.omnix_engine.OmnixEngine._build_multi_step_coordinator') as mock_build_coordinator, \
         patch('core.omnix_engine.OmnixEngine._build_agent_observability_sink') as mock_build_sink, \
         patch('core.omnix_engine.OmnixEngine._build_progress_broadcaster') as mock_build_broadcaster, \
         patch('core.omnix_engine.OmnixEngine._build_app_dispatcher') as mock_build_dispatcher, \
         patch('core.omnix_engine.OmnixEngine._build_task_event_publisher') as mock_build_publisher, \
         patch('core.omnix_engine.OmnixConfig') as mock_config_class:

        mock_task_executor_instance = Mock(spec=TaskExecutor)
        mock_task_executor_class.return_value = mock_task_executor_instance
        mock_config_instance = Mock()
        mock_config_class.return_value = mock_config_instance
        # FIX: Properly mock config for LLM provider resolution
        mock_extra = Mock()
        mock_extra.get.return_value = "mock"
        mock_config_instance.extra = mock_extra
        mock_config_instance.vision_confidence_threshold = 0.5
        mock_config_instance.default_action_timeout_s = 30.0
        mock_config_instance.screen_width = 1920
        mock_config_instance.screen_height = 1080
        mock_config_instance.inactivity_timeout_s = 30.0
        mock_config_instance.vision_max_screenshot_stale_s = 5.0
        mock_resolve_llm.return_value = Mock()  # Mock LLM provider
        mock_interpreter_instance = Mock()
        mock_interpreter_class.return_value = mock_interpreter_instance
        mock_registry_instance = Mock()
        mock_build_registry.return_value = mock_registry_instance
        mock_planner_instance = Mock()
        mock_planner_class.return_value = mock_planner_instance
        mock_step_verifier_instance = Mock()
        mock_step_verifier_class.return_value = mock_step_verifier_instance
        mock_goal_verifier_instance = Mock()
        mock_goal_verifier_class.return_value = mock_goal_verifier_instance
        mock_recovery_engine_instance = Mock()
        mock_recovery_engine_class.return_value = mock_recovery_engine_instance
        mock_obs_provider_instance = Mock()
        mock_obs_provider_class.return_value = mock_obs_provider_instance
        mock_policy_instance = Mock()
        mock_policy_class.return_value = mock_policy_instance
        mock_vision_provider_instance = Mock()
        mock_build_vision.return_value = mock_vision_provider_instance
        mock_coordinator_instance = Mock()
        mock_build_coordinator.return_value = mock_coordinator_instance
        mock_sink_instance = Mock()
        mock_build_sink.return_value = mock_sink_instance
        mock_broadcaster_instance = Mock()
        mock_build_broadcaster.return_value = mock_broadcaster_instance
        mock_dispatcher_instance = Mock()
        mock_build_dispatcher.return_value = mock_dispatcher_instance
        mock_publisher_func = Mock()
        mock_build_publisher.return_value = mock_publisher_func
        mock_agent_instance = Mock()
        mock_agent_class.return_value = mock_agent_instance

        # Create mock bus and health objects for testing
        mock_bus = Mock()
        mock_health = Mock()

        engine = OmnixEngine(mock_config_instance, bus=mock_bus, health=mock_health)

        # Trigger pipeline building
        pipeline = engine._build_pipeline()

        # Verify Agent was created with task_executor as plan_executor
        mock_agent_class.assert_called_once()
        call_args, call_kwargs = mock_agent_class.call_args
        # The plan_executor argument should be our task_executor instance
        assert call_kwargs['plan_executor'] == mock_task_executor_instance


def test_omnix_engine_falls_back_to_plan_executor_when_task_executor_unavailable():
    """Test that OmnixEngine uses plan_executor when TaskExecutor is not available"""
    with patch('core.task.executor.TaskExecutor') as mock_task_executor_class, \
         patch('core.orchestration.Agent') as mock_agent_class, \
         patch('core.orchestration.PlanExecutorImpl') as mock_plan_executor_class, \
         patch('core.omnix_engine.OmnixEngine._resolve_llm_provider') as mock_resolve_llm, \
         patch('ai.intent.interpreter.LLMIntentInterpreter') as mock_interpreter_class, \
         patch('ai.intent.specs.build_default_registry') as mock_build_registry, \
         patch('ai.brain.deterministic.DeterministicPlanner') as mock_planner_class, \
         patch('core.orchestration.verifier.DefaultStepVerifier') as mock_step_verifier_class, \
         patch('core.orchestration.verifier.DefaultGoalVerifier') as mock_goal_verifier_class, \
         patch('core.orchestration.recovery.DefaultRecoveryEngine') as mock_recovery_engine_class, \
         patch('core.orchestration.observation.CapabilityResultObservationProvider') as mock_obs_provider_class, \
         patch('core.orchestration.agent.AgentPolicy') as mock_policy_class, \
         patch('core.omnix_engine.OmnixEngine._build_vision_target_provider') as mock_build_vision, \
         patch('core.omnix_engine.OmnixEngine._build_multi_step_coordinator') as mock_build_coordinator, \
         patch('core.omnix_engine.OmnixEngine._build_agent_observability_sink') as mock_build_sink, \
         patch('core.omnix_engine.OmnixEngine._build_progress_broadcaster') as mock_build_broadcaster, \
         patch('core.omnix_engine.OmnixEngine._build_app_dispatcher') as mock_build_dispatcher, \
         patch('core.omnix_engine.OmnixEngine._build_task_event_publisher') as mock_build_publisher, \
         patch('core.omnix_engine.OmnixConfig') as mock_config_class:

        mock_task_executor_class.side_effect = Exception("Build failed")
        mock_plan_executor_instance = Mock()
        mock_plan_executor_class.return_value = mock_plan_executor_instance
        mock_agent_instance = Mock()
        mock_agent_class.return_value = mock_agent_instance
        mock_config_instance = Mock()
        mock_config_class.return_value = mock_config_instance
        # FIX: Properly mock config for LLM provider resolution
        mock_extra = Mock()
        mock_extra.get.return_value = "mock"
        mock_config_instance.extra = mock_extra
        mock_config_instance.vision_confidence_threshold = 0.5
        mock_config_instance.default_action_timeout_s = 30.0
        mock_config_instance.screen_width = 1920
        mock_config_instance.screen_height = 1080
        mock_config_instance.inactivity_timeout_s = 30.0
        mock_config_instance.vision_max_screenshot_stale_s = 5.0
        mock_resolve_llm.return_value = Mock()  # Mock LLM provider
        mock_interpreter_instance = Mock()
        mock_interpreter_class.return_value = mock_interpreter_instance
        mock_registry_instance = Mock()
        mock_build_registry.return_value = mock_registry_instance
        mock_planner_instance = Mock()
        mock_planner_class.return_value = mock_planner_instance
        mock_step_verifier_instance = Mock()
        mock_step_verifier_class.return_value = mock_step_verifier_instance
        mock_goal_verifier_instance = Mock()
        mock_goal_verifier_class.return_value = mock_goal_verifier_instance
        mock_recovery_engine_instance = Mock()
        mock_recovery_engine_class.return_value = mock_recovery_engine_instance
        mock_obs_provider_instance = Mock()
        mock_obs_provider_class.return_value = mock_obs_provider_instance
        mock_policy_instance = Mock()
        mock_policy_class.return_value = mock_policy_instance
        mock_vision_provider_instance = Mock()
        mock_build_vision.return_value = mock_vision_provider_instance
        mock_coordinator_instance = Mock()
        mock_build_coordinator.return_value = mock_coordinator_instance
        mock_sink_instance = Mock()
        mock_build_sink.return_value = mock_sink_instance
        mock_broadcaster_instance = Mock()
        mock_build_broadcaster.return_value = mock_broadcaster_instance
        mock_dispatcher_instance = Mock()
        mock_build_dispatcher.return_value = mock_dispatcher_instance
        mock_publisher_func = Mock()
        mock_build_publisher.return_value = mock_publisher_func

        engine = OmnixEngine(mock_config_instance)
        # Manually set the plan_executor that would have been built
        engine.plan_executor = mock_plan_executor_instance
        engine.bus = Mock()
        engine.health = Mock()

        # Trigger pipeline building
        pipeline = engine._build_pipeline()

        # Verify Agent was created with plan_executor as plan_executor (fallback)
        mock_agent_class.assert_called_once()
        call_args, call_kwargs = mock_agent_class.call_args
        # The plan_executor argument should be our plan_executor instance (fallback)
        assert call_kwargs['plan_executor'] == mock_plan_executor_instance


def test_task_executor_event_publisher():
    """Test that TaskExecutor gets event publisher from engine"""
    with patch('core.task.executor.TaskExecutor') as mock_task_executor_class, \
         patch('core.omnix_engine.OmnixEngine._resolve_llm_provider') as mock_resolve_llm, \
         patch('ai.intent.interpreter.LLMIntentInterpreter') as mock_interpreter_class, \
         patch('ai.intent.specs.build_default_registry') as mock_build_registry, \
         patch('ai.brain.deterministic.DeterministicPlanner') as mock_planner_class, \
         patch('core.orchestration.verifier.DefaultStepVerifier') as mock_step_verifier_class, \
         patch('core.orchestration.verifier.DefaultGoalVerifier') as mock_goal_verifier_class, \
         patch('core.orchestration.recovery.DefaultRecoveryEngine') as mock_recovery_engine_class, \
         patch('core.orchestration.observation.CapabilityResultObservationProvider') as mock_obs_provider_class, \
         patch('core.orchestration.agent.AgentPolicy') as mock_policy_class, \
         patch('core.omnix_engine.OmnixEngine._build_vision_target_provider') as mock_build_vision, \
         patch('core.omnix_engine.OmnixEngine._build_multi_step_coordinator') as mock_build_coordinator, \
         patch('core.omnix_engine.OmnixEngine._build_agent_observability_sink') as mock_build_sink, \
         patch('core.omnix_engine.OmnixEngine._build_progress_broadcaster') as mock_build_broadcaster, \
         patch('core.omnix_engine.OmnixEngine._build_app_dispatcher') as mock_build_dispatcher, \
         patch('core.omnix_engine.OmnixEngine._build_task_event_publisher') as mock_build_publisher, \
         patch('core.omnix_engine.OmnixConfig') as mock_config_class:

        mock_task_executor_instance = Mock(spec=TaskExecutor)
        mock_task_executor_class.return_value = mock_task_executor_instance
        mock_publisher_func = Mock()
        mock_build_publisher.return_value = mock_publisher_func
        mock_config_instance = Mock()
        mock_config_class.return_value = mock_config_instance
        # FIX: Properly mock config for LLM provider resolution
        mock_extra = Mock()
        mock_extra.get.return_value = "mock"
        mock_config_instance.extra = mock_extra
        mock_config_instance.vision_confidence_threshold = 0.5
        mock_config_instance.default_action_timeout_s = 30.0
        mock_config_instance.screen_width = 1920
        mock_config_instance.screen_height = 1080
        mock_config_instance.inactivity_timeout_s = 30.0
        mock_config_instance.vision_max_screenshot_stale_s = 5.0
        mock_resolve_llm.return_value = Mock()  # Mock LLM provider
        mock_interpreter_instance = Mock()
        mock_interpreter_class.return_value = mock_interpreter_instance
        mock_registry_instance = Mock()
        mock_build_registry.return_value = mock_registry_instance
        mock_planner_instance = Mock()
        mock_planner_class.return_value = mock_planner_instance
        mock_step_verifier_instance = Mock()
        mock_step_verifier_class.return_value = mock_step_verifier_instance
        mock_goal_verifier_instance = Mock()
        mock_goal_verifier_class.return_value = mock_goal_verifier_instance
        mock_recovery_engine_instance = Mock()
        mock_recovery_engine_class.return_value = mock_recovery_engine_instance
        mock_obs_provider_instance = Mock()
        mock_obs_provider_class.return_value = mock_obs_provider_instance
        mock_policy_instance = Mock()
        mock_policy_class.return_value = mock_policy_instance
        mock_vision_provider_instance = Mock()
        mock_build_vision.return_value = mock_vision_provider_instance
        mock_coordinator_instance = Mock()
        mock_build_coordinator.return_value = mock_coordinator_instance
        mock_sink_instance = Mock()
        mock_build_sink.return_value = mock_sink_instance
        mock_broadcaster_instance = Mock()
        mock_build_broadcaster.return_value = mock_broadcaster_instance
        mock_dispatcher_instance = Mock()
        mock_build_dispatcher.return_value = mock_dispatcher_instance

        engine = OmnixEngine(mock_config_instance)
        engine.bus = Mock()  # Mock event bus

        # Build the pipeline to trigger TaskExecutor construction
        engine._build_pipeline()

        # Verify TaskExecutor was constructed with event_publisher in config
        mock_task_executor_class.assert_called_once()
        call_args, call_kwargs = mock_task_executor_class.call_args
        # The event_publisher should be in the config
        assert 'config' in call_kwargs
        config = call_kwargs['config']
        assert hasattr(config, 'event_publisher')
        assert config.event_publisher == mock_publisher_func


if __name__ == "__main__":
    pytest.main([__file__, "-v"])