"""
Unit tests for recovery model, policy, and classifier.
"""

import pytest
from core.orchestration.models import (
    Failure,
    FailureKind,
    RecoveryDecision,
    RecoveryAction,
    ExpectedEffect,
    Observation,
    ObservationSource,
)
from core.orchestration.recovery import (
    RecoveryPolicy,
    _DEFAULT_KIND_TO_ACTION,
    _DEFAULT_RATIONALE,
    _DEFAULT_PER_KIND_BACKOFF,
    DefaultRecoveryEngine,
)


# ===========================================================================
# Recovery Model Tests
# ===========================================================================

def test_failure_construction():
    """Test Failure model construction and immutability."""
    failure = Failure(
        failure_id="f1",
        kind=FailureKind.EXECUTION,
        step_id="s1",
        plan_id="p1",
        message="something went wrong",
        cause="simulated error",
        attempt=2,
        is_retryable=False,
        metadata={"key": "value"},
    )
    assert failure.failure_id == "f1"
    assert failure.kind == FailureKind.EXECUTION
    assert failure.step_id == "s1"
    assert failure.plan_id == "p1"
    assert failure.message == "something went wrong"
    assert failure.cause == "simulated error"
    assert failure.attempt == 2
    assert failure.is_retryable is False
    assert failure.metadata == {"key": "value"}

    # Test immutability: attempting to modify should raise
    with pytest.raises(Exception):
        failure.failure_id = "f2"


def test_failure_to_dict():
    """Test Failure serialization to dict."""
    failure = Failure(
        failure_id="f1",
        kind=FailureKind.EXECUTION,
        step_id="s1",
        plan_id="p1",
        message="test",
        attempt=1,
    )
    result = failure.to_dict()
    assert result["type"] == "Failure"
    assert result["failure_id"] == "f1"
    assert result["kind"] == "execution"
    assert result["step_id"] == "s1"
    assert result["plan_id"] == "p1"
    assert result["message"] == "test"
    assert result["attempt"] == 1
    assert result["is_retryable"] is True
    assert result["metadata"] == {}


def test_recovery_decision_construction():
    """Test RecoveryDecision model construction."""
    decision = RecoveryDecision(
        decision_id="d1",
        action=RecoveryAction.RETRY_WITH_BACKOFF,
        failure_id="f1",
        backoff_s=1.5,
        ask_user_message="Please confirm",
        rationale="transient failure",
        metadata={"info": "test"},
    )
    assert decision.decision_id == "d1"
    assert decision.action == RecoveryAction.RETRY_WITH_BACKOFF
    assert decision.failure_id == "f1"
    assert decision.backoff_s == 1.5
    assert decision.ask_user_message == "Please confirm"
    assert decision.rationale == "transient failure"
    assert decision.metadata == {"info": "test"}

    # Test immutability
    with pytest.raises(Exception):
        decision.decision_id = "d2"


def test_recovery_decision_to_dict():
    """Test RecoveryDecision serialization to dict."""
    decision = RecoveryDecision(
        decision_id="d1",
        action=RecoveryAction.GIVE_UP,
        failure_id="f1",
        rationale="giving up",
    )
    result = decision.to_dict()
    assert result["type"] == "RecoveryDecision"
    assert result["decision_id"] == "d1"
    assert result["action"] == "give_up"
    assert result["failure_id"] == "f1"
    assert result["rationale"] == "giving up"
    assert result["backoff_s"] == 0.0
    assert result["ask_user_message"] == ""
    assert result["new_step"] is None
    assert result["metadata"] == {}


# ===========================================================================
# Recovery Policy Tests
# ===========================================================================

def test_recovery_policy_defaults():
    """Test RecoveryPolicy default values."""
    policy = RecoveryPolicy()
    assert policy.max_attempts_per_step == 2
    assert policy.max_replans == 2
    assert policy.max_total_runtime_s == 120.0
    assert policy.backoff_s == 0.0
    assert policy.per_kind_backoff_s == {}
    assert policy.ask_user_on_uncertain is True


def test_recovery_policy_with_overrides():
    """Test RecoveryPolicy.with_overrides returns new instance with overrides."""
    policy = RecoveryPolicy(
        max_attempts_per_step=3,
        max_replans=1,
        backoff_s=0.5,
    )
    overridden = policy.with_overrides(
        max_attempts_per_step=5,
        max_total_runtime_s=300.0,
        ask_user_on_uncertain=False,
    )
    # Original unchanged
    assert policy.max_attempts_per_step == 3
    assert policy.max_replans == 1
    assert policy.max_total_runtime_s == 120.0
    assert policy.backoff_s == 0.5
    assert policy.ask_user_on_uncertain is True
    # Overridden has new values
    assert overridden.max_attempts_per_step == 5
    assert overridden.max_replans == 1  # not overridden
    assert overridden.max_total_runtime_s == 300.0
    assert overridden.backoff_s == 0.5  # not overridden
    assert overridden.ask_user_on_uncertain is False


# ===========================================================================
# Recovery Classifier Tests (mappings)
# ===========================================================================

def test_default_kind_to_action_mapping():
    """Test that each FailureKind maps to the expected RecoveryAction."""
    # Check all FailureKind enum members are covered
    assert set(_DEFAULT_KIND_TO_ACTION.keys()) == set(FailureKind)
    # Spot-check some known mappings
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.EXECUTION] == RecoveryAction.RETRY_WITH_BACKOFF
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.VERIFICATION] == RecoveryAction.REPLAN
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.TIMEOUT] == RecoveryAction.REPLAN
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.CANCELLED] == RecoveryAction.GIVE_UP
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.SAFETY] == RecoveryAction.GIVE_UP
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.UNKNOWN_CAPABILITY] == RecoveryAction.GIVE_UP
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.INVALID_PARAMETERS] == RecoveryAction.GIVE_UP
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.PLAN_INFEASIBLE] == RecoveryAction.REPLAN
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.INTERNAL] == RecoveryAction.GIVE_UP
    # UI failure kinds (Phase 1/D23 + Phase 3)
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.TARGET_NOT_FOUND] == RecoveryAction.REPLAN
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.FOCUS_FAILED] == RecoveryAction.RETRY
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.WINDOW_NOT_READY] == RecoveryAction.RETRY_WITH_BACKOFF
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.STALE_TARGET] == RecoveryAction.REPLAN
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.PROVIDER_FAILURE] == RecoveryAction.RETRY_WITH_BACKOFF
    assert _DEFAULT_KIND_TO_ACTION[FailureKind.PERMISSION_FAILURE] == RecoveryAction.ASK_USER


def test_default_rationale_mapping():
    """Test that each RecoveryAction has a rationale string."""
    assert set(_DEFAULT_RATIONALE.keys()) == set(RecoveryAction)
    for action, rationale in _DEFAULT_RATIONALE.items():
        assert isinstance(rationale, str)
        assert len(rationale) > 0
    # Spot-check
    assert _DEFAULT_RATIONALE[RecoveryAction.RETRY] == "transient failure; retrying the same step"
    assert _DEFAULT_RATIONALE[RecoveryAction.RETRY_WITH_BACKOFF] == "transient failure; retrying with backoff"
    assert _DEFAULT_RATIONALE[RecoveryAction.REPLAN] == "step failed irrecoverably; producing a new plan"
    assert _DEFAULT_RATIONALE[RecoveryAction.ABORT] == "aborting the whole plan"
    assert _DEFAULT_RATIONALE[RecoveryAction.ASK_USER] == "asking the user to clarify"
    assert _DEFAULT_RATIONALE[RecoveryAction.GIVE_UP] == "exhausted recovery budget; giving up"


def test_default_per_kind_backoff():
    """Test the default per-kind backoff mapping."""
    # Only two kinds have defaults in the canonical map
    assert _DEFAULT_PER_KIND_BACKOFF[FailureKind.WINDOW_NOT_READY] == 1.0
    assert _DEFAULT_PER_KIND_BACKOFF[FailureKind.PROVIDER_FAILURE] == 2.0
    # Ensure no other kinds are in the default map (should be exactly these two)
    assert set(_DEFAULT_PER_KIND_BACKOFF.keys()) == {
        FailureKind.WINDOW_NOT_READY,
        FailureKind.PROVIDER_FAILURE,
    }


# ===========================================================================
# Recovery Engine Classifier Behavior Tests
# ===========================================================================

def test_engine_uses_default_mapping():
    """Test that the recovery engine uses the default mapping when no overrides."""
    # Use a policy with the canonical per-kind backoff so we can test backoff values
    policy = RecoveryPolicy(per_kind_backoff_s=dict(_DEFAULT_PER_KIND_BACKOFF))
    engine = DefaultRecoveryEngine(policy=policy)
    # Reset state for clean test
    engine.reset()

    # Test EXECUTION -> RETRY_WITH_BACKOFF (with backoff from per_kind_backoff_s if applicable)
    failure = Failure(
        failure_id="f1",
        kind=FailureKind.EXECUTION,
        step_id="s1",
        attempt=1,
    )
    context = None  # not used in this simple test
    decision = engine.decide(failure, context)
    # EXECUTION maps to RETRY_WITH_BACKOFF, but backoff depends on kind.
    # EXECUTION is not in _DEFAULT_PER_KIND_BACKOFF, so uses global backoff_s (0.0 by default)
    assert decision.action == RecoveryAction.RETRY_WITH_BACKOFF
    assert decision.backoff_s == 0.0

    # Test WINDOW_NOT_READY -> RETRY_WITH_BACKOFF with 1.0s backoff
    failure2 = Failure(
        failure_id="f2",
        kind=FailureKind.WINDOW_NOT_READY,
        step_id="s2",
        attempt=1,
    )
    decision2 = engine.decide(failure2, context)
    assert decision2.action == RecoveryAction.RETRY_WITH_BACKOFF
    assert decision2.backoff_s == 1.0

    # Test PROVIDER_FAILURE -> RETRY_WITH_BACKOFF with 2.0s backoff
    failure3 = Failure(
        failure_id="f3",
        kind=FailureKind.PROVIDER_FAILURE,
        step_id="s3",
        attempt=1,
    )
    decision3 = engine.decide(failure3, context)
    assert decision3.action == RecoveryAction.RETRY_WITH_BACKOFF
    assert decision3.backoff_s == 2.0

    # Test SAFETY -> GIVE_UP
    failure4 = Failure(
        failure_id="f4",
        kind=FailureKind.SAFETY,
        step_id="s4",
        attempt=1,
    )
    decision4 = engine.decide(failure4, context)
    assert decision4.action == RecoveryAction.GIVE_UP
    assert decision4.backoff_s == 0.0


def test_engine_respects_action_overrides():
    """Test that action_overrides override the default mapping."""
    overrides = {
        FailureKind.EXECUTION: RecoveryAction.REPLAN,  # normally RETRY_WITH_BACKOFF
        FailureKind.SAFETY: RecoveryAction.RETRY_WITH_BACKOFF,  # normally GIVE_UP
    }
    policy = RecoveryPolicy()
    engine = DefaultRecoveryEngine(policy=policy, action_overrides=overrides)
    engine.reset()

    # EXECUTION should now be REPLAN
    failure_exec = Failure(
        failure_id="f_exec",
        kind=FailureKind.EXECUTION,
        step_id="s_exec",
        attempt=1,
    )
    decision_exec = engine.decide(failure_exec, None)
    assert decision_exec.action == RecoveryAction.REPLAN

    # SAFETY should now be RETRY_WITH_BACKOFF
    failure_safety = Failure(
        failure_id="f_safety",
        kind=FailureKind.SAFETY,
        step_id="s_safety",
        attempt=1,
    )
    decision_safety = engine.decide(failure_safety, None)
    assert decision_safety.action == RecoveryAction.RETRY_WITH_BACKOFF