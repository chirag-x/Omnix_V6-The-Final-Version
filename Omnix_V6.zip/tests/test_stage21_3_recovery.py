"""
Tests for Stage 21: TaskExecutor recovery and retry logic
"""

from unittest.mock import Mock, patch
import pytest
from core.task.executor import TaskExecutor, TaskExecutorConfig
from core.task.models import Task, TaskStatus, TaskResult, TaskFailure, TaskKind, TaskPlan, TaskStep
from core.orchestration.execution_result import ExecutionResult, ExecutionOutcome
from uuid import uuid4
import time

# Helper function to create a mock ExecutionResult
def mock_execution_result(success=True, step_id="step1", error=None):
    return ExecutionResult(
        execution_id=str(uuid4()),
        plan_id=str(uuid4()),
        goal_id=str(uuid4()),
        outcome=ExecutionOutcome.COMPLETED if success else ExecutionOutcome.FAILED,
        step_results=(),
        started_at=time.time(),
        completed_at=time.time(),
        duration_ms=10.0,
        correlation_id=str(uuid4()),
        error=error,
        metadata={}
    )

def test_task_executor_config_defaults():
    """Test TaskExecutorConfig has expected defaults"""
    config = TaskExecutorConfig()
    assert config.max_task_retries == 2
    assert config.enable_step_recovery == True
    assert config.enable_task_replanning == True
    assert config.progress_callback is None
    assert config.event_publisher is None


def test_task_executor_config_custom_values():
    """Test TaskExecutorConfig accepts custom values"""
    callback = Mock()
    publisher = Mock()
    config = TaskExecutorConfig(
        max_task_retries=5,
        enable_step_recovery=False,
        enable_task_replanning=False,
        progress_callback=callback,
        event_publisher=publisher
    )
    assert config.max_task_retries == 5
    assert config.enable_step_recovery == False
    assert config.enable_task_replanning == False
    assert config.progress_callback == callback
    assert config.event_publisher == publisher


def test_execute_task_basic_flow():
    """Test basic task execution flow"""
    mock_plan_executor = Mock()
    # Configure the mock to return a successful execution result for the step
    mock_plan_executor.execute.return_value = mock_execution_result(success=True)

    executor = TaskExecutor(plan_executor=mock_plan_executor, config=TaskExecutorConfig(max_task_retries=0))

    # Create a task without a plan (so the executor will create a simple plan)
    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
    )

    result = executor.execute_task(mock_task)

    # Verify that the plan executor was called
    assert mock_plan_executor.execute.called
    # Verify the result is successful
    assert result.is_successful == True
    assert result.status == TaskStatus.COMPLETED
    assert result.steps_completed == 1
    assert result.steps_total == 1


def test_execute_with_retries_success_first_try():
    """Test _execute_with_retries succeeds on first attempt"""
    mock_plan_executor = Mock()
    mock_plan_executor.execute.return_value = mock_execution_result(success=True)
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=TaskExecutorConfig(max_task_retries=3))

    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
    )

    # We are testing the internal method _execute_with_retries, but we can also test via execute_task
    # Since max_task_retries=0, it will call _execute_with_retries which will call _execute_task_attempt once.
    result = executor.execute_task(mock_task)

    # The internal _execute_with_retries should have been called once (via the task execution)
    # We can't easily mock it without breaking, so we trust that if the task succeeds, the retry logic worked.
    assert result.is_successful == True


def test_execute_with_retries_fails_then_succeeds():
    """Test _execute_with_retries fails first attempt then succeeds"""
    mock_plan_executor = Mock()
    # First call returns failed, second returns success
    mock_plan_executor.execute.side_effect = [
        mock_execution_result(success=False, error="First attempt failed"),
        mock_execution_result(success=True)
    ]
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=TaskExecutorConfig(max_task_retries=3))

    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
    )

    result = executor.execute_task(mock_task)

    # Should have succeeded eventually
    assert result.is_successful == True
    # Should have called the plan executor twice
    assert mock_plan_executor.execute.call_count == 2


def test_execute_with_retries_exhausts_retries():
    """Test _execute_with_retries fails all attempts"""
    mock_plan_executor = Mock()
    mock_plan_executor.execute.return_value = mock_execution_result(success=False, error="All attempts failed")
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=TaskExecutorConfig(max_task_retries=2, enable_step_recovery=False))

    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
    )

    result = executor.execute_task(mock_task)

    # Should have failed
    assert result.is_successful == False
    assert result.status == TaskStatus.FAILED
    # Should have called the plan executor max_retries + 1 times (3 times for max_retries=2)
    assert mock_plan_executor.execute.call_count == 3


def test_execute_task_attempt_creates_plan_when_missing():
    """Test _execute_task_attempt creates a plan when task has no plan"""
    mock_plan_executor = Mock()
    mock_plan_executor.execute.return_value = mock_execution_result(success=True)
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Task without plan
    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
        # plan is None by default
    )

    result = executor.execute_task(mock_task)

    # Should have created a plan and executed it
    assert mock_plan_executor.execute.called
    assert result.is_successful == True


def test_execute_task_attempt_uses_existing_plan():
    """Test _execute_task_attempt uses existing plan when present"""
    mock_plan_executor = Mock()
    mock_plan_executor.execute.return_value = mock_execution_result(success=True)
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Create a simple plan
    step = TaskStep(
        step_id=str(uuid4()),
        sequence=0,
        description="Test step",
        intent="Test goal",
        capability="automation.general",
        parameters={},
        expected_result="Goal achieved",
        dependencies=frozenset(),
    )
    plan = TaskPlan(
        plan_id=str(uuid4()),
        user_goal="Test goal",
        steps=(step,),
    )

    # Task with existing plan
    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION,
        plan=plan
    )

    result = executor.execute_task(mock_task)

    # Should have executed the plan
    assert mock_plan_executor.execute.called
    assert result.is_successful == True


def test_execute_task_plan_basic():
    """Test _execute_task_plan basic execution"""
    mock_plan_executor = Mock()
    mock_plan_executor.execute.return_value = mock_execution_result(success=True)
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=TaskExecutorConfig())

    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
    )

    # Create a plan with one step
    step = TaskStep(
        step_id=str(uuid4()),
        sequence=0,
        description="Test step",
        intent="Test goal",
        capability="automation.general",
        parameters={},
        expected_result="Goal achieved",
        dependencies=frozenset(),
    )
    plan = TaskPlan(
        plan_id=str(uuid4()),
        user_goal="Test goal",
        steps=(step,),
    )

    mock_task = mock_task.to_builder().with_plan(plan).build()

    result = executor.execute_task(mock_task)

    # Should have executed the plan step
    assert mock_plan_executor.execute.call_count == 1
    assert result.is_successful == True


def test_execute_task_plan_with_step_failures_no_recovery():
    """Test _execute_task_plan stops on step failure when recovery disabled"""
    mock_plan_executor = Mock()
    # First step succeeds, second step fails
    mock_plan_executor.execute.side_effect = [
        mock_execution_result(success=True),
        mock_execution_result(success=False, error="Step failed")
    ]
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=TaskExecutorConfig(enable_step_recovery=False, max_task_retries=0))

    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
    )

    # Create a plan with two steps
    step1 = TaskStep(
        step_id=str(uuid4()),
        sequence=0,
        description="Test step 1",
        intent="Test goal part 1",
        capability="automation.general",
        parameters={},
        expected_result="Part 1 achieved",
        dependencies=frozenset(),
    )
    step2 = TaskStep(
        step_id=str(uuid4()),
        sequence=1,
        description="Test step 2",
        intent="Test goal part 2",
        capability="automation.general",
        parameters={},
        expected_result="Part 2 achieved",
        dependencies=frozenset(),
    )
    plan = TaskPlan(
        plan_id=str(uuid4()),
        user_goal="Test goal",
        steps=(step1, step2),
    )

    mock_task = mock_task.to_builder().with_plan(plan).build()

    result = executor.execute_task(mock_task)

    # Should have executed both steps (the first succeeds, the second fails)
    assert mock_plan_executor.execute.call_count == 2
    # Since recovery is disabled, the task should fail because of the second step
    assert result.is_successful == False
    assert result.status == TaskStatus.FAILED


def test_execute_task_plan_with_step_failures_with_recovery():
    """Test _execute_task_plan handles step failure when recovery enabled"""
    mock_plan_executor = Mock()
    # First step succeeds, second step fails on first attempt but succeeds on retry
    mock_plan_executor.execute.side_effect = [
        mock_execution_result(success=True),  # Step 1 attempt 1
        mock_execution_result(success=False, error="Step failed"),  # Step 2 attempt 1
        mock_execution_result(success=True)   # Step 2 attempt 2 (retry)
    ]
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=TaskExecutorConfig(enable_step_recovery=True, max_task_retries=2))

    mock_task = Task(
        task_id="test-task",
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION
    )

    # Create a plan with two steps
    step1 = TaskStep(
        step_id=str(uuid4()),
        sequence=0,
        description="Test step 1",
        intent="Test goal part 1",
        capability="automation.general",
        parameters={},
        expected_result="Part 1 achieved",
        dependencies=frozenset(),
    )
    step2 = TaskStep(
        step_id=str(uuid4()),
        sequence=1,
        description="Test step 2",
        intent="Test goal part 2",
        capability="automation.general",
        parameters={},
        expected_result="Part 2 achieved",
        dependencies=frozenset(),
    )
    plan = TaskPlan(
        plan_id=str(uuid4()),
        user_goal="Test goal",
        steps=(step1, step2),
    )

    mock_task = mock_task.to_builder().with_plan(plan).build()

    result = executor.execute_task(mock_task)

    # Should have executed: step1 once, step2 twice (first attempt and retry)
    assert mock_plan_executor.execute.call_count == 3
    # With recovery enabled and the retry succeeding, the task should succeed
    assert result.is_successful == True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])