from core.task.models import create_task_step, create_task_plan

# Simple test - let's manually create a circular dependency and see if we can detect it
print("Creating a simple circular dependency: A -> B -> A")

# Create step A
step_a = create_task_step(0, "Step A", "Intent A", "cap_a")
print(f"Step A ID: {step_a.step_id}")

# Create step B that depends on A
step_b = create_task_step(1, "Step B", "Intent B", "cap_b", dependencies=frozenset([step_a.step_id]))
print(f"Step B ID: {step_b.step_id}")
print(f"Step B dependencies: {step_b.dependencies}")

# Now recreate step A to depend on B (creating the circle)
step_a_circular = create_task_step(0, "Step A", "Intent A", "cap_a", dependencies=frozenset([step_b.step_id]))
print(f"Step A circular ID: {step_a_circular.step_id}")
print(f"Step A circular dependencies: {step_a_circular.dependencies}")

# Create plan with both steps
plan = create_task_plan("Test goal", (step_a_circular, step_b))
print(f"Plan step count: {plan.step_count}")

# Check for circular dependency
result = plan.has_circular_dependency()
print(f"Has circular dependency: {result}")

# Let's also trace through the algorithm
print("\nTracing algorithm:")
visited = set()
rec_stack = set()

def has_cycle(step_id):
    print(f"  has_cycle({step_id})")
    step = plan.get_step_by_id(step_id)
    if not step:
        print(f"    ERROR: Step not found!")
        return False

    print(f"    Found step: {step.step_id}")

    if step_id in rec_stack:
        print(f"    CYCLE DETECTED!")
        return True

    if step_id in visited:
        print(f"    Already visited")
        return False

    visited.add(step_id)
    rec_stack.add(step_id)
    print(f"    Added to visited and rec_stack")

    for dep_id in step.dependencies:
        print(f"    Checking dependency {dep_id}")
        if has_cycle(dep_id):
            return True

    rec_stack.remove(step_id)
    print(f"    Removed from rec_stack")
    return False

print("Checking each step:")
for step in plan.steps:
    if step.step_id not in visited:
        print(f"  Starting from {step.step_id}")
        if has_cycle(step.step_id):
            print("  CYCLE FOUND!")
            break
else:
    print("  No cycle found")