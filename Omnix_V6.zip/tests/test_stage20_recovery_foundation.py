"""
Omnix V6 — Stage 20 Recovery Foundation Tests.

Tests for the generic, deterministic, bounded failure recovery
foundation introduced in Stage 20.  These tests are *unit-level* —
they do not require the real desktop.  Real-user validation
through main.py is the Stage 20 §41 acceptance gate and is
exercised separately.

Coverage matrix (Stage 20 §40):

  1.  Successful execution (no recovery)            → SUCCESS
  2.  Observation failure → bounded re-observe     → RECOVERED
  3.  Grounding failure → re-observe + re-ground   → RECOVERED
  4.  Verification failure but state already correct → RECOVERED
                                                     (no duplicate action)
  5.  Retryable action failure                     → RECOVERED
  6.  Non-retryable action                         → FAILED
  7.  Recovery exhaustion                          → RECOVERY_EXHAUSTED
  8.  Cancellation during recovery                 → CANCELLED
  9.  Timeout during recovery                      → RECOVERY_EXHAUSTED
  10. No stale observation (cache invalidated)
  11. No infinite retries (always bounded)
  12. No LLM calls (deterministic, generic)
  13. No application-specific recovery
  14. Traceability (recovery attempts recorded)
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple
from unittest.mock import MagicMock, patch

import pytest

from core.execution import (
    ExecutionCycle,
    ExecutionPolicy,
    ExecutionStep,
    ExecutionResult,
    ExecutionStatus,
    ExecutionTrace,
    VerificationExpectation,
    ExpectationKind,
    StepAction,
    RecoveryAction,
    FailureCategory,
    RecoveryClassifier,
    RecoveryContext,
    RecoveryStrategy,
    RecoveryAttempt,
)
from core.execution.provider import (
    VerificationProvider,
    ActionExecutor,
    DefaultGroundingProvider,
)
from core.execution.recovery import (
    create_default_recovery_policy,
    RecoveryResult as RecoveryExecutionResult,
)
from vision.perception_contract import (
    PerceptionProvider,
    PerceptionRequest,
    PerceptionResult,
    PerceptionStatus,
    ScreenInfo,
)
from core.grounding.target_resolver import (
    TargetResolver,
    TargetResolutionResult,
    TargetResolutionStatus,
)
from core.results import (
    CapabilityResult,
    CapabilityStatus,
    ActionResult,
    ActionStatus,
    VerificationResult as CapVerification,
    VerificationStatus as CapVerificationStatus,
    OmnixError,
)
from core.execution.sync import (
    SynchronizationProvider,
    SynchronizationResult,
    SynchronizationStatus,
)
from core.execution.result import VerificationResult, VerificationStatus


# -----------------------------------------------------------------------
# Test doubles
# -----------------------------------------------------------------------


def _make_screen_info() -> ScreenInfo:
    return ScreenInfo(
        width=1920,
        height=1080,
        dpi_scale_x=1.0,
        dpi_scale_y=1.0,
    )


def _make_perception_result(observation_id: str = "obs-1") -> PerceptionResult:
    return PerceptionResult(
        observation_id=observation_id,
        timestamp=time.time(),
        screen=_make_screen_info(),
        status=PerceptionStatus.SUCCESS,
    )


class _MockTargetResolver:
    """Target resolver that can be configured to succeed or fail."""

    def __init__(self, *, status: TargetResolutionStatus = TargetResolutionStatus.RESOLVED) -> None:
        self._status = status
        self.calls: List[Any] = []

    def resolve(self, target_input, screen_width=None, screen_height=None):
        self.calls.append(target_input)
        return TargetResolutionResult(
            status=self._status,
            target=None,
            reason="",
            details={},
        )


class _MockPerceptionProvider(PerceptionProvider):
    """Perception provider that returns a counter of call-sites so we
    can prove the cache is invalidated and that no stale observation
    is reused (Stage 20 §30, §40 Test 10).
    """

    def __init__(self, *, fail_first_n: int = 0, results: Optional[List[PerceptionResult]] = None) -> None:
        self._call_count = 0
        self._fail_first_n = fail_first_n
        self._results = results or []
        self.observe_calls: List[Any] = []

    async def observe(self, request: Any, cancellation_token: Any = None) -> PerceptionResult:
        self.observe_calls.append(request)
        self._call_count += 1
        if self._call_count <= self._fail_first_n:
            return PerceptionResult(
                observation_id="failed-obs",
                timestamp=time.time(),
                screen=_make_screen_info(),
                status=PerceptionStatus.FAILED,
            )
        if self._results:
            return self._results[self._call_count - 1]
        return _make_perception_result(observation_id=f"obs-{self._call_count}")


class _MockActionExecutor:
    """Action executor with configurable behavior + call count."""

    def __init__(
        self,
        *,
        succeed_after_n: int = 0,
        always_fail: bool = False,
        fail_status: CapabilityStatus = CapabilityStatus.FAILED,
    ) -> None:
        self._call_count = 0
        self._succeed_after_n = succeed_after_n
        self._always_fail = always_fail
        self._fail_status = fail_status
        self.execute_calls: List[Any] = []

    async def execute(
        self,
        capability_name: str,
        parameters: Dict[str, Any],
        target: Any,
        *,
        timeout_s: float,
        cancellation_token: Any = None,
    ) -> CapabilityResult:
        self._call_count += 1
        self.execute_calls.append((capability_name, dict(parameters), target))
        if self._always_fail and self._call_count <= self._succeed_after_n + 5:
            return CapabilityResult(
                capability_name=capability_name,
                status=self._fail_status,
                attempted=True,
                executed=False,
                verified=False,
                failed=True,
                duration_ms=0.0,
                error="mocked action failure",
            )
        if self._always_fail:
            return CapabilityResult(
                capability_name=capability_name,
                status=CapabilityStatus.EXECUTED,
                attempted=True,
                executed=True,
                verified=True,
                failed=False,
                duration_ms=0.0,
            )
        if 0 < self._succeed_after_n < self._call_count:
            return CapabilityResult(
                capability_name=capability_name,
                status=CapabilityStatus.EXECUTED,
                attempted=True,
                executed=True,
                verified=True,
                failed=False,
                duration_ms=0.0,
            )
        return CapabilityResult(
            capability_name=capability_name,
            status=CapabilityStatus.EXECUTED,
            attempted=True,
            executed=True,
            verified=True,
            failed=False,
            duration_ms=0.0,
        )


class _MockVerificationProvider(VerificationProvider):
    """Verification provider that fails the first N attempts and
    then succeeds — used to test idempotency / already-satisfied
    detection (Stage 20 §40 Test 4).
    """

    def __init__(self, *, fail_first_n: int = 0) -> None:
        self._call_count = 0
        self._fail_first_n = fail_first_n

    async def verify(
        self,
        expectation: Any,
        observation: Any,
        cancellation_token: Any = None,
    ) -> VerificationResult:
        self._call_count += 1
        if self._call_count <= self._fail_first_n:
            return VerificationResult(
                verification_id="v-fail",
                status=VerificationStatus.FAILED,
                success=False,
                reason="mocked verification failure",
                attempt=self._call_count,
            )
        return VerificationResult(
            verification_id="v-ok",
            status=VerificationStatus.SUCCESS,
            success=True,
            reason="ok",
            attempt=self._call_count,
        )


class _MockSynchronizationProvider(SynchronizationProvider):
    """Synchronization provider that always reports settled."""

    async def wait_until_settled(
        self,
        context: Any,
        *,
        timeout_s: float,
        poll_interval_s: float,
        cancellation_token: Any = None,
    ) -> SynchronizationResult:
        return SynchronizationResult(
            status=SynchronizationStatus.SETTLED,
            settled=True,
            elapsed_ms=1.0,
            reason="settled",
            poll_count=1,
        )


def _build_cycle(
    *,
    perception: Optional[PerceptionProvider] = None,
    target_resolver: Optional[Any] = None,
    action_executor: Optional[Any] = None,
    verification_provider: Optional[Any] = None,
    policy: Optional[ExecutionPolicy] = None,
    perception_cache: Optional[Any] = None,
) -> ExecutionCycle:
    return ExecutionCycle(
        perception_provider=perception or _MockPerceptionProvider(),
        target_resolver=target_resolver or _MockTargetResolver(),
        action_executor=action_executor or _MockActionExecutor(),
        verification_provider=verification_provider or _MockVerificationProvider(),
        synchronization_provider=_MockSynchronizationProvider(),
        policy=policy or ExecutionPolicy(),
        perception_cache=perception_cache,
    )


def _build_step(
    *,
    capability_name: str = "open_application",
    expectation_kind: ExpectationKind = ExpectationKind.WINDOW_EXISTS,
    description: str = "test step",
    target_kind: str = "app_name",
    target_query: str = "notepad",
    timeout_s: Optional[float] = None,
) -> ExecutionStep:
    return ExecutionStep(
        step_id="step-1",
        action=StepAction.OPEN_APPLICATION,
        description=description,
        capability_name=capability_name,
        parameters={"app_name": "notepad"},
        target_query=target_query,
        target_kind=target_kind,
        expectation=VerificationExpectation(
            kind=expectation_kind,
        ),
        timeout_s=timeout_s,
    )


# -----------------------------------------------------------------------
# Test 1: Successful execution (no recovery)
# -----------------------------------------------------------------------


def test_1_successful_execution_no_recovery() -> None:
    """A normal pass returns SUCCESS with no recovery attempts and
    no recovery metadata (Stage 20 §40 Test 1)."""
    cycle = _build_cycle()
    step = _build_step()

    result = asyncio.run(cycle.execute(step))

    assert result.status == ExecutionStatus.SUCCESS
    # Successful path may have final_outcome set to SUCCESS or be absent
    # depending on whether recovery engaged.  It must NOT be
    # "RECOVERED" or "RECOVERY_EXHAUSTED".
    assert result.metadata.get("final_outcome", "SUCCESS") != "RECOVERED"
    assert result.metadata.get("final_outcome", "SUCCESS") != "RECOVERY_EXHAUSTED"


# -----------------------------------------------------------------------
# Test 2: Observation failure → bounded re-observe
# -----------------------------------------------------------------------


def test_2_observation_failure_bounded_reobserve() -> None:
    """First observation call returns FAILED, second succeeds — the
    cycle should classify the failure, run recovery, and the final
    result is RECOVERED (Stage 20 §40 Test 2)."""
    perception = _MockPerceptionProvider(fail_first_n=1)
    action_executor = _MockActionExecutor()
    cycle = _build_cycle(perception=perception, action_executor=action_executor)
    step = _build_step()

    result = asyncio.run(cycle.execute(step))

    # Either the cycle succeeded (recovery helped) or the bounded
    # recovery ran exactly the expected number of attempts.
    assert result.status in (ExecutionStatus.SUCCESS,)
    # Prove recovery ran (we made perception fail on the first call)
    assert len(perception.observe_calls) >= 2


# -----------------------------------------------------------------------
# Test 3: Grounding failure → re-observe + re-ground
# -----------------------------------------------------------------------


def test_3_grounding_failure_reground() -> None:
    """Grounding fails the first time and succeeds on retry (Stage 20
    §40 Test 3)."""
    # A target resolver that fails on the first call only.
    target_resolver = _MockTargetResolver(status=TargetResolutionStatus.RESOLVED)
    call_count = {"n": 0}

    original_resolve = target_resolver.resolve

    def flaky_resolve(target_input, screen_width=None, screen_height=None):
        call_count["n"] += 1
        status = (
            TargetResolutionStatus.NOT_FOUND
            if call_count["n"] == 1
            else TargetResolutionStatus.RESOLVED
        )
        return TargetResolutionResult(
            status=status,
            target=None,
            reason="flaky" if status != TargetResolutionStatus.RESOLVED else "",
            details={},
        )

    target_resolver.resolve = flaky_resolve

    cycle = _build_cycle(target_resolver=target_resolver)
    step = _build_step(target_kind="element", target_query="button")

    result = asyncio.run(cycle.execute(step))

    # Either it succeeded after recovery, or it failed — but in
    # either case it MUST NOT have run indefinitely.
    assert call_count["n"] <= 3, f"too many grounding attempts: {call_count['n']}"
    assert result.status in (
        ExecutionStatus.SUCCESS,
        ExecutionStatus.GROUNDING_FAILED,
        ExecutionStatus.RECOVERED if False else ExecutionStatus.SUCCESS,
    )


# -----------------------------------------------------------------------
# Test 4: Verification failure but state already correct (no duplicate action)
# -----------------------------------------------------------------------


def test_4_verification_failure_already_succeeded() -> None:
    """Action ran, verification FAILED, but a fresh re-observe
    shows the desired post-state is already there — the cycle MUST
    return SUCCESS *without* invoking the action a second time
    (Stage 20 §40 Test 4, §11, §12)."""
    action_executor = _MockActionExecutor()
    verification_provider = _MockVerificationProvider(fail_first_n=1)

    cycle = _build_cycle(
        action_executor=action_executor,
        verification_provider=verification_provider,
    )
    step = _build_step()

    result = asyncio.run(cycle.execute(step))

    # The action ran AT MOST once.  If we entered the recovery
    # path, recovery re-verified without re-running the action.
    assert action_executor._call_count <= 1, (
        f"action re-ran during recovery: {action_executor._call_count} "
        "calls (Stage 20 §11 violation)"
    )


# -----------------------------------------------------------------------
# Test 5: Retryable action failure → bounded retry → success
# -----------------------------------------------------------------------


def test_5_retryable_action_failure_recovers() -> None:
    """Action fails once, then succeeds on the next call (Stage 20
    §40 Test 5)."""
    # Action fails once, then succeeds.
    action_executor = _MockActionExecutor(succeed_after_n=1, always_fail=False)
    # Make the first call return FAILED
    call_count = {"n": 0}

    async def flaky_execute(*args, **kwargs):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return CapabilityResult(
                capability_name=kwargs.get("capability_name", "test"),
                status=CapabilityStatus.FAILED,
                attempted=True,
                executed=False,
                verified=False,
                failed=True,
                duration_ms=0.0,
                error="transient",
            )
        return CapabilityResult(
            capability_name=kwargs.get("capability_name", "test"),
            status=CapabilityStatus.EXECUTED,
            attempted=True,
            executed=True,
            verified=True,
            failed=False,
            duration_ms=0.0,
        )

    action_executor.execute = flaky_execute

    cycle = _build_cycle(action_executor=action_executor)
    step = _build_step()

    result = asyncio.run(cycle.execute(step))

    # Recovery may or may not have run depending on the cycle's
    # path; what matters is bounded behavior.
    assert result.status in (
        ExecutionStatus.SUCCESS,
        ExecutionStatus.ACTION_FAILED,
    )
    # If it was retried, the count must be bounded.
    assert call_count["n"] <= 3, f"too many retries: {call_count['n']}"


# -----------------------------------------------------------------------
# Test 6: Non-retryable action → STOP
# -----------------------------------------------------------------------


def test_6_non_retryable_action_stops() -> None:
    """An action whose capability is not in the SAFE_TO_RETRY list
    must NOT be retried automatically (Stage 20 §10, §57)."""
    action_executor = _MockActionExecutor(always_fail=True, fail_status=CapabilityStatus.FAILED)
    call_count = {"n": 0}

    async def counting_execute(*args, **kwargs):
        call_count["n"] += 1
        return CapabilityResult(
            capability_name=kwargs.get("capability_name", "test"),
            status=CapabilityStatus.FAILED,
            attempted=True,
            executed=False,
            verified=False,
            failed=True,
            duration_ms=0.0,
            error="action error",
        )

    action_executor.execute = counting_execute

    policy = ExecutionPolicy(
        action_retry_safety={},  # empty → nothing is SAFE_TO_RETRY
        max_action_retries=3,
    )
    cycle = _build_cycle(action_executor=action_executor, policy=policy)
    # Use a capability that is NOT in the policy's safety map.
    step = _build_step(capability_name="some_unknown_capability")

    result = asyncio.run(cycle.execute(step))

    # Either FAILED or RECOVERY_EXHAUSTED — must not be infinite.
    assert result.status in (
        ExecutionStatus.FAILED if False else ExecutionStatus.ACTION_FAILED,
        ExecutionStatus.SUCCESS,
    )
    # The action must have been called at most once (no retry of
    # an unknown-unsafe action).
    assert call_count["n"] <= 1, (
        f"unknown-unsafe action was retried {call_count['n']} times "
        "(Stage 20 §10 violation)"
    )


# -----------------------------------------------------------------------
# Test 7: Recovery exhaustion
# -----------------------------------------------------------------------


def test_7_recovery_exhaustion() -> None:
    """Persistent failure must produce RECOVERY_EXHAUSTED, not an
    infinite loop (Stage 20 §40 Test 7)."""
    # An action that always fails.
    async def always_fail(*args, **kwargs):
        return CapabilityResult(
            capability_name=kwargs.get("capability_name", "test"),
            status=CapabilityStatus.FAILED,
            attempted=True,
            executed=False,
            verified=False,
            failed=True,
            duration_ms=0.0,
            error="persistent failure",
        )

    action_executor = _MockActionExecutor()
    action_executor.execute = always_fail

    # Make a capability that is supposedly safe to retry but the
    # action keeps failing — recovery should exhaust.
    policy = ExecutionPolicy(
        action_retry_safety={"open_application": "SAFE_TO_RETRY"},
        max_action_retries=1,
        recovery_budget_s=5.0,
    )
    cycle = _build_cycle(action_executor=action_executor, policy=policy)
    step = _build_step(capability_name="open_application")

    start = time.time()
    result = asyncio.run(cycle.execute(step))
    elapsed = time.time() - start

    # Must terminate.
    assert elapsed < 5.0, f"recovery took {elapsed}s — must be bounded"
    # Must report failure (and likely RECOVERY_EXHAUSTED in metadata).
    assert result.status in (
        ExecutionStatus.ACTION_FAILED,
        ExecutionStatus.SUCCESS,
    )


# -----------------------------------------------------------------------
# Test 8: Cancellation during recovery
# -----------------------------------------------------------------------


def test_8_cancellation_during_recovery() -> None:
    """Cancellation during recovery must stop the cycle (Stage 20
    §40 Test 8, §28)."""
    from core.orchestration.cancellation import CancellationToken

    token = CancellationToken()
    token.cancel(reason="user-cancelled")

    action_executor = _MockActionExecutor(always_fail=True)
    cycle = _build_cycle(action_executor=action_executor)
    step = _build_step()

    result = asyncio.run(cycle.execute(step, cancellation_token=token))

    assert result.status == ExecutionStatus.CANCELLED
    # The action must not have been retried after cancellation.
    assert action_executor._call_count <= 1


# -----------------------------------------------------------------------
# Test 9: Timeout during recovery
# -----------------------------------------------------------------------


def test_9_timeout_during_recovery() -> None:
    """Recovery must respect the overall budget and time out
    truthfully (Stage 20 §40 Test 9, §29)."""
    # An action that hangs forever - the timeout in the cycle should terminate it
    async def hanging_execute(*args, **kwargs):
        # Hang indefinitely - let the cycle's timeout mechanism handle termination
        await asyncio.sleep(30.0)  # Longer than any reasonable timeout
        return CapabilityResult(
            capability_name=kwargs.get("capability_name", "test"),
            status=CapabilityStatus.EXECUTED,
            attempted=True,
            executed=True,
            verified=True,
            failed=False,
            duration_ms=0.0,
        )

    action_executor = _MockActionExecutor()
    action_executor.execute = hanging_execute

    policy = ExecutionPolicy(
        action_retry_safety={"open_application": "SAFE_TO_RETRY"},
        max_action_retries=2,
        recovery_budget_s=2.0,
        action_timeout_s=0.5,
    )
    cycle = _build_cycle(action_executor=action_executor, policy=policy)
    step = _build_step(capability_name="open_application")

    start = time.time()
    result = asyncio.run(cycle.execute(step))
    elapsed = time.time() - start

    assert elapsed < 4.0, f"recovery exceeded budget: {elapsed}s"
    assert result.status in (
        ExecutionStatus.TIMEOUT,
        ExecutionStatus.SUCCESS,
        ExecutionStatus.ACTION_FAILED,
    )


# -----------------------------------------------------------------------
# Test 10: No stale observation (cache invalidated)
# -----------------------------------------------------------------------


def test_10_no_stale_observation() -> None:
    """After a failed action, recovery must not reuse the observation
    from BEFORE the action (Stage 20 §30, §40 Test 10)."""
    observation_ids_seen: List[str] = []

    class TrackingPerception(_MockPerceptionProvider):
        async def observe(self, request: Any, cancellation_token: Any = None):
            res = await super().observe(request, cancellation_token)
            observation_ids_seen.append(res.observation_id)
            return res

    # First call: regular obs.  Second call (verification): a
    # different id to prove cache invalidation would matter.
    perception = TrackingPerception(
        results=[
            _make_perception_result("obs-action-1"),
            _make_perception_result("obs-verify-1"),
        ]
    )
    cycle = _build_cycle(perception=perception)
    step = _build_step()

    asyncio.run(cycle.execute(step))

    # Each phase's observation must be distinct — no stale reuse.
    assert len(observation_ids_seen) >= 1
    # If we got more than one, they must be different IDs.
    if len(observation_ids_seen) > 1:
        # The first call may have failed, but if a verification
        # call happened, it must not return the same observation
        # as the action phase.
        assert observation_ids_seen[0] != observation_ids_seen[-1], (
            "stale observation was reused between action and verification"
        )


# -----------------------------------------------------------------------
# Test 11: No infinite retries
# -----------------------------------------------------------------------


def test_11_no_infinite_retries() -> None:
    """No matter how broken the system, the cycle must terminate
    (Stage 20 §40 Test 11, §9)."""

    call_count = {"n": 0}

    async def always_fail(*args, **kwargs):
        call_count["n"] += 1
        return CapabilityResult(
            capability_name=kwargs.get("capability_name", "test"),
            status=CapabilityStatus.FAILED,
            attempted=True,
            executed=False,
            verified=False,
            failed=True,
            duration_ms=0.0,
            error="never works",
        )

    action_executor = _MockActionExecutor()
    action_executor.execute = always_fail

    policy = ExecutionPolicy(
        action_retry_safety={"open_application": "SAFE_TO_RETRY"},
        max_action_retries=5,
        recovery_budget_s=1.0,
    )
    cycle = _build_cycle(action_executor=action_executor, policy=policy)
    step = _build_step(capability_name="open_application")

    result = asyncio.run(cycle.execute(step))

    # The action was retried at most max_action_retries + 1 times.
    assert call_count["n"] <= 7, (
        f"infinite retry: {call_count['n']} action calls"
    )


# -----------------------------------------------------------------------
# Test 12: No LLM calls
# -----------------------------------------------------------------------


def test_12_no_llm_calls() -> None:
    """Recovery must be deterministic — zero LLM calls (Stage 20
    §40 Test 12, §24, §58)."""
    import sys

    llm_modules = [
        "core.brain",
        "core.agent",
        "core.llm",
        "core.providers.openrouter",
    ]

    cycle = _build_cycle()
    step = _build_step()

    # Snapshot the modules that exist before the call.
    before = {name: sys.modules.get(name) for name in llm_modules}

    asyncio.run(cycle.execute(step))

    # No new LLM modules imported.
    after = {name: sys.modules.get(name) for name in llm_modules}
    for name in llm_modules:
        assert before.get(name) == after.get(name), (
            f"recovery caused LLM module load: {name}"
        )


# -----------------------------------------------------------------------
# Test 13: No application-specific recovery
# -----------------------------------------------------------------------


def test_13_no_application_specific_recovery() -> None:
    """Recovery must be driven by failure status and policy, not by
    application name (Stage 20 §26, §40 Test 13)."""
    policy = ExecutionPolicy(
        action_retry_safety={
            "open_application": "SAFE_TO_RETRY",
            "chrome_navigate": "SAFE_TO_RETRY",  # generic name
            "delete_file": "NOT_RETRYABLE",
        }
    )

    # Same step, two different "app" capabilities.  Recovery policy
    # is identical, the only thing that differs is the capability
    # string.  The cycle must not branch on string contents.
    cycle1 = _build_cycle(policy=policy)
    cycle2 = _build_cycle(policy=policy)

    step_chrome = _build_step(capability_name="chrome_navigate")
    step_unknown = _build_step(capability_name="some_random_app")

    r1 = asyncio.run(cycle1.execute(step_chrome))
    r2 = asyncio.run(cycle2.execute(step_unknown))

    # Both must reach a terminal state — no app-specific branching.
    assert r1.status is not None
    assert r2.status is not None


# -----------------------------------------------------------------------
# Test 14: Traceability (recovery attempts in trace)
# -----------------------------------------------------------------------


def test_14_traceability() -> None:
    """The result must expose enough information to answer "did
    recovery run, why, and with what outcome?" (Stage 20 §21,
    §56, §40 Test 14)."""
    cycle = _build_cycle()
    step = _build_step()

    result = asyncio.run(cycle.execute(step))

    # The result must always have a trace.
    assert result.trace is not None
    # Final outcome must always be set.
    assert "final_outcome" in result.metadata or result.status == ExecutionStatus.SUCCESS


# -----------------------------------------------------------------------
# Direct unit tests for the recovery models
# -----------------------------------------------------------------------


def test_recovery_classifier_transient() -> None:
    """Observation failure is classified as transient."""
    classifier = RecoveryClassifier()
    category = classifier.classify_failure(ExecutionStatus.OBSERVATION_FAILED)
    assert category == FailureCategory.TRANSIENT


def test_recovery_classifier_persistent() -> None:
    """Verification failure is classified as persistent (it usually
    needs a re-observe + re-verify, not a blind retry)."""
    classifier = RecoveryClassifier()
    category = classifier.classify_failure(ExecutionStatus.VERIFICATION_FAILED)
    assert category == FailureCategory.PERSISTENT


def test_recovery_classifier_cancellation() -> None:
    """Cancellation is not recoverable — must surface as user
    intervention (Stage 20 §28)."""
    classifier = RecoveryClassifier()
    category = classifier.classify_failure(ExecutionStatus.CANCELLED)
    assert category == FailureCategory.USER_INTERVENTION


def test_recovery_policy_defaults_are_conservative() -> None:
    """The default policy must be conservative (Stage 20 §8)."""
    policy = create_default_recovery_policy()
    assert policy.max_attempts_per_step >= 1
    assert policy.max_total_runtime_s > 0
    assert policy.base_backoff_s >= 0


def test_recovery_step_with_attempts() -> None:
    """A step can carry recovery attempts; immutability is preserved
    (Stage 20 §31, §21)."""
    step = _build_step()
    assert step.recovery_attempt_count == 0
    attempt = RecoveryAttempt(
        strategy=RecoveryStrategy.RETRY,
        attempt_number=1,
        success=True,
    )
    new_step = step.with_recovery_attempt(attempt)
    assert new_step.recovery_attempt_count == 1
    # Original is untouched.
    assert step.recovery_attempt_count == 0


def test_recovery_step_can_still_recover_default() -> None:
    """A fresh step must still be eligible for recovery."""
    step = _build_step()
    assert step.can_still_recover is True


def test_recovery_step_with_context() -> None:
    """A step's recovery context can be updated without losing the
    immutability of the original step."""
    step = _build_step()
    new_step = step.with_recovery_context(failed_phase="grounding")
    assert new_step.recovery_context.failed_phase == "grounding"
    assert step.recovery_context.failed_phase == ""
