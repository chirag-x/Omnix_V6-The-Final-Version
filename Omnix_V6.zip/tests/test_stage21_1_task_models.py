"""
Tests for Stage 21: Task models validation
"""

from core.task.models import (
    Task,
    TaskPlan,
    TaskStep,
    TaskStatus,
    TaskKind,
    TaskResult,
    TaskFailure,
    create_task,
    create_task_step,
    create_task_plan
)
import time


def test_task_creation():
    """Test creating a task with factory function"""
    task = create_task(
        user_goal="Test goal",
        task_kind=TaskKind.AUTOMATION,
        metadata={"test": "value"}
    )

    assert task.user_goal == "Test goal"
    assert task.task_kind == TaskKind.AUTOMATION
    assert task.status == TaskStatus.PENDING
    assert task.metadata["test"] == "value"
    assert task.task_id is not None
    assert len(task.task_id) > 0


def test_task_step_creation():
    """Test creating a task step with factory function"""
    step = create_task_step(
        sequence=0,
        description="Test step",
        intent="Test intent",
        capability="test.capability",
        parameters={"param": "value"},
        expected_result="Success",
        verification_capability="test.verify"
    )

    assert step.step_id is not None
    assert step.sequence == 0
    assert step.description == "Test step"
    assert step.intent == "Test intent"
    assert step.capability == "test.capability"
    assert step.parameters["param"] == "value"
    assert step.expected_result == "Success"
    assert step.verification_capability == "test.verify"
    assert step.dependencies == frozenset()
    assert step.retry_count == 0
    assert step.max_retries == 3


def test_task_step_with_dependencies():
    """Test creating a task step with dependencies"""
    step = create_task_step(
        sequence=1,
        description="Dependent step",
        intent="Dependent intent",
        capability="test.capability2",
        dependencies=frozenset(["step-1", "step-2"])
    )

    assert step.dependencies == frozenset(["step-1", "step-2"])


def test_task_step_with_updated_retry_count():
    """Test TaskStep.with_updated_retry_count method"""
    step = create_task_step(
        sequence=0,
        description="Test step",
        intent="Test intent",
        capability="test.capability",
        max_retries=5
    )

    updated_step = step.with_updated_retry_count()

    assert updated_step.retry_count == 1
    assert step.retry_count == 0  # Original unchanged
    assert updated_step.max_retries == 5
    assert updated_step.step_id == step.step_id
    assert updated_step.description == step.description


def test_task_plan_creation():
    """Test creating a task plan with factory function"""
    step1 = create_task_step(0, "Step 1", "Intent 1", "cap1")
    step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1.step_id]))

    plan = create_task_plan(
        user_goal="Test goal",
        steps=(step1, step2),
        timeout_s=600.0,
        max_retries=3
    )

    assert plan.plan_id is not None
    assert plan.user_goal == "Test goal"
    assert plan.step_count == 2
    assert plan.timeout_s == 600.0
    assert plan.max_retries == 3
    assert len(plan.steps) == 2
    assert plan.steps[0] == step1
    assert plan.steps[1] == step2


def test_task_plan_get_step_by_id():
    """Test TaskPlan.get_step_by_id method"""
    step1 = create_task_step(0, "Step 1", "Intent 1", "cap1")
    step2 = create_task_step(1, "Step 2", "Intent 2", "cap2")

    plan = create_task_plan("Test goal", (step1, step2))

    assert plan.get_step_by_id(step1.step_id) == step1
    assert plan.get_step_by_id(step2.step_id) == step2
    assert plan.get_step_by_id("non-existent") is None


def test_task_plan_get_ready_steps():
    """Test TaskPlan.get_ready_steps method"""
    step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset())
    step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1.step_id]))
    step3 = create_task_step(2, "Step 3", "Intent 3", "cap3", dependencies=frozenset([step1.step_id, step2.step_id]))

    plan = create_task_plan("Test goal", (step1, step2, step3))

    # Initially no steps completed
    ready = plan.get_ready_steps(frozenset())
    assert len(ready) == 1
    assert ready[0] == step1

    # After step1 completed
    ready = plan.get_ready_steps(frozenset([step1.step_id]))
    assert len(ready) == 1
    assert ready[0] == step2

    # After step1 and step2 completed
    ready = plan.get_ready_steps(frozenset([step1.step_id, step2.step_id]))
    assert len(ready) == 1
    assert ready[0] == step3


def test_task_plan_has_circular_dependency():
    """Test TaskPlan.has_circular_dependency method"""
    # No circular dependency
    step1 = create_task_step(0, "Step 1", "Intent 1", "cap1", dependencies=frozenset())
    step2 = create_task_step(1, "Step 2", "Intent 2", "cap2", dependencies=frozenset([step1.step_id]))
    plan1 = create_task_plan("Test goal", (step1, step2))
    assert plan1.has_circular_dependency() == False

    # Circular dependency: 1 -> 2 -> 3 -> 4 -> 1
    # To create this, we need:
    # Step 1 depends on Step 4
    # Step 2 depends on Step 1
    # Step 3 depends on Step 2
    # Step 4 depends on Step 3

    # Create TaskStep objects directly with predictable IDs for testing
    from uuid import UUID
    step1 = TaskStep(
        step_id="step1",
        sequence=0,
        description="Step 1",
        intent="Intent 1",
        capability="cap1",
        dependencies=frozenset(["step4"])  # Step 1 depends on Step 4
    )
    step2 = TaskStep(
        step_id="step2",
        sequence=1,
        description="Step 2",
        intent="Intent 2",
        capability="cap2",
        dependencies=frozenset(["step1"])  # Step 2 depends on Step 1
    )
    step3 = TaskStep(
        step_id="step3",
        sequence=2,
        description="Step 3",
        intent="Intent 3",
        capability="cap3",
        dependencies=frozenset(["step2"])  # Step 3 depends on Step 2
    )
    step4 = TaskStep(
        step_id="step4",
        sequence=3,
        description="Step 4",
        intent="Intent 4",
        capability="cap4",
        dependencies=frozenset(["step3"])  # Step 4 depends on Step 3
    )

    plan2 = create_task_plan("Test goal", (step1, step2, step3, step4))
    assert plan2.has_circular_dependency() == True


def test_task_result_properties():
    """Test TaskResult properties"""
    from core.orchestration.models import FailureKind

    result = TaskResult(
        task_id="test-task",
        status=TaskStatus.COMPLETED,
        steps_completed=5,
        steps_total=5,
        start_time=1000.0,
        end_time=1010.0
    )

    assert result.task_id == "test-task"
    assert result.status == TaskStatus.COMPLETED
    assert result.steps_completed == 5
    assert result.steps_total == 5
    assert result.start_time == 1000.0
    assert result.end_time == 1010.0
    assert result.duration_ms == 10000.0  # 10 seconds * 1000
    assert result.is_successful == True
    assert result.progress_percentage == 100.0

    # Test with failure
    failure = TaskFailure(
        step_id="step-3",
        failure_kind=FailureKind.EXECUTION,
        message="Something went wrong"
    )

    result_with_failure = TaskResult(
        task_id="test-task",
        status=TaskStatus.FAILED,
        steps_completed=2,
        steps_total=5,
        start_time=1000.0,
        end_time=1005.0,
        failure=failure
    )

    assert result_with_failure.is_successful == False
    assert result_with_failure.progress_percentage == 40.0  # 2/5 * 100
    assert result_with_failure.failure == failure


def test_task_to_dict():
    """Test Task.to_dict method"""
    task = create_task(
        user_goal="Test goal",
        task_kind=TaskKind.CREATION,
        metadata={"key": "value"}
    )

    task_dict = task.to_dict()

    assert task_dict["user_goal"] == "Test goal"
    assert task_dict["task_kind"] == TaskKind.CREATION.value
    assert task_dict["status"] == TaskStatus.PENDING.value
    assert task_dict["metadata"]["key"] == "value"
    assert "task_id" in task_dict
    assert "created_at" in task_dict


def test_task_step_to_dict():
    """Test TaskStep.to_dict method"""
    step = create_task_step(
        sequence=0,
        description="Test step",
        intent="Test intent",
        capability="test.capability",
        parameters={"param": "value"},
        expected_result="Success"
    )

    step_dict = step.to_dict()

    assert step_dict["sequence"] == 0
    assert step_dict["description"] == "Test step"
    assert step_dict["intent"] == "Test intent"
    assert step_dict["capability"] == "test.capability"
    assert step_dict["parameters"]["param"] == "value"
    assert step_dict["expected_result"] == "Success"
    assert step_dict["dependencies"] == []


def test_task_plan_to_dict():
    """Test TaskPlan.to_dict method"""
    step = create_task_step(0, "Test step", "Test intent", "test.cap")
    plan = create_task_plan("Test goal", (step,))

    plan_dict = plan.to_dict()

    assert plan_dict["user_goal"] == "Test goal"
    assert plan_dict["step_count"] == 1
    assert len(plan_dict["steps"]) == 1
    assert plan_dict["steps"][0]["description"] == "Test step"
    assert "plan_id" in plan_dict
    assert "created_at" in plan_dict


if __name__ == "__main__":
    pytest.main([__file__, "-v"])