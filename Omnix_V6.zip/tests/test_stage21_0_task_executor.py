"""
Tests for Stage 21: TaskExecutor basic functionality
"""

import pytest
from unittest.mock import Mock, MagicMock
from core.task.executor import TaskExecutor, TaskExecutorConfig
from core.task.models import Task, TaskStatus
from core.orchestration.execution_result import ExecutionResult, ExecutionOutcome
from core.orchestration.models import ExecutionContext, Goal, Plan


def test_task_executor_initialization():
    """Test TaskExecutor initializes correctly with default config"""
    mock_plan_executor = Mock()
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    assert executor.plan_executor == mock_plan_executor
    assert executor.config.max_task_retries == 2
    assert executor.config.enable_step_recovery == True
    assert executor.config.enable_task_replanning == True
    assert executor._active_tasks == {}
    assert executor._task_plans == {}


def test_task_executor_initialization_with_config():
    """Test TaskExecutor initializes correctly with custom config"""
    mock_plan_executor = Mock()
    config = TaskExecutorConfig(
        max_task_retries=5,
        enable_step_recovery=False,
        enable_task_replanning=False
    )
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=config)

    assert executor.config.max_task_retries == 5
    assert executor.config.enable_step_recovery == False
    assert executor.config.enable_task_replanning == False


def test_execute_method_adapter():
    """Test TaskExecutor.execute method adapts ExecutionContext to Task execution"""
    mock_plan_executor = Mock()
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Mock the execute_task method to return a known result
    mock_task_result = Mock()
    mock_task_result.is_successful = True
    mock_task_result.steps_completed = 3
    mock_task_result.steps_total = 3
    mock_task_result.start_time = 1000.0
    mock_task_result.end_time = 1005.0
    mock_task_result.duration_ms = 5000.0
    mock_task_result.failure = None
    mock_task_result.task_id = "test-task-id"
    mock_task_result.metadata = {}
    # Set the status to COMPLETED for successful task
    from core.task.models import TaskStatus
    mock_task_result.status = TaskStatus.COMPLETED

    executor.execute_task = Mock(return_value=mock_task_result)

    # Create test execution context
    goal = Goal(
        goal_id="test-goal-id",
        description="Test goal",
        success_criteria=(),
        constraints=()
    )

    plan = Mock()
    plan.plan_id = "test-plan-id"
    plan.steps = []

    context = ExecutionContext(
        execution_id="test-execution-id",
        goal=goal,
        plan=plan
    )

    # Execute
    result = executor.execute(context)

    # Verify execute_task was called
    executor.execute_task.assert_called_once()

    # Verify result is ExecutionResult
    assert isinstance(result, ExecutionResult)
    assert result.execution_id == "test-execution-id"
    assert result.goal_id == "test-goal-id"
    assert result.outcome == ExecutionOutcome.COMPLETED
    # correlation_id is not passed through in this implementation
    assert result.correlation_id == ""


def test_execute_method_without_plan():
    """Test TaskExecutor.execute method works when context has no plan"""
    mock_plan_executor = Mock()
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Mock the execute_task method to return a known result
    mock_task_result = Mock()
    mock_task_result.is_successful = True
    mock_task_result.steps_completed = 1
    mock_task_result.steps_total = 1
    mock_task_result.start_time = 1000.0
    mock_task_result.end_time = 1002.0
    mock_task_result.duration_ms = 2000.0
    mock_task_result.failure = None
    mock_task_result.task_id = "test-task-id"
    mock_task_result.metadata = {}

    executor.execute_task = Mock(return_value=mock_task_result)

    # Create test execution context without plan
    goal = Goal(
        goal_id="test-goal-id",
        description="Test goal",
        success_criteria=(),
        constraints=()
    )

    context = ExecutionContext(
        execution_id="test-execution-id",
        goal=goal,
        plan=None  # No plan provided
    )

    # Execute
    result = executor.execute(context)

    # Verify execute_task was called
    executor.execute_task.assert_called_once()

    # Verify result is ExecutionResult
    assert isinstance(result, ExecutionResult)
    assert result.execution_id == "test-execution-id"
    assert result.goal_id == "test-goal-id"


def test_get_task_status():
    """Test get_task_status returns correct status for active tasks"""
    mock_plan_executor = Mock()
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Initially no tasks
    assert executor.get_task_status("non-existent") is None

    # Add a mock task
    mock_task = Mock()
    mock_task.status = TaskStatus.RUNNING
    executor._active_tasks["test-task"] = mock_task

    # Should return the status
    assert executor.get_task_status("test-task") == TaskStatus.RUNNING

    # Non-existent task should return None
    assert executor.get_task_status("another-task") is None


def test_get_active_tasks():
    """Test get_active_tasks returns list of active tasks"""
    mock_plan_executor = Mock()
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Initially empty
    assert executor.get_active_tasks() == []

    # Add mock tasks
    mock_task1 = Mock()
    mock_task2 = Mock()
    executor._active_tasks["task1"] = mock_task1
    executor._active_tasks["task2"] = mock_task2

    active_tasks = executor.get_active_tasks()
    assert len(active_tasks) == 2
    assert mock_task1 in active_tasks
    assert mock_task2 in active_tasks


def test_cancel_task():
    """Test cancel_task properly cancels active tasks"""
    mock_plan_executor = Mock()
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Add a mock task that's not completed
    mock_task = Mock()
    mock_task.is_completed = False
    mock_task.to_builder().status.return_value.completed_at.return_value.build.return_value = Mock()
    executor._active_tasks["test-task"] = mock_task

    # Mock the emit method
    executor._emit_task_event = Mock()

    # Cancel the task
    result = executor.cancel_task("test-task")

    # Should return True for successful cancellation
    assert result == True

    # Should have updated the task
    mock_task.to_builder().status.assert_called()

    # Should have emitted cancellation event
    executor._emit_task_event.assert_called_with(
        "task_cancelled",
        mock_task.to_builder().status.return_value.completed_at.return_value.build.return_value,
        None
    )


def test_cancel_task_already_completed():
    """Test cancel_task returns False for already completed tasks"""
    mock_plan_executor = Mock()
    mock_event_publisher = Mock()
    config = TaskExecutorConfig(event_publisher=mock_event_publisher)
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=config)

    # Add a mock task that's already completed
    mock_task = Mock()
    mock_task.is_completed = True
    executor._active_tasks["test-task"] = mock_task

    # Try to cancel
    result = executor.cancel_task("test-task")

    # Should return False
    assert result == False

    # Should not have emitted any events
    mock_event_publisher.assert_not_called()


def test_cancel_task_nonexistent():
    """Test cancel_task returns False for non-existent tasks"""
    mock_plan_executor = Mock()
    mock_event_publisher = Mock()
    config = TaskExecutorConfig(event_publisher=mock_event_publisher)
    executor = TaskExecutor(plan_executor=mock_plan_executor, config=config)

    # Try to cancel non-existent task
    result = executor.cancel_task("non-existent-task")

    # Should return False
    assert result == False

    # Should not have emitted any events
    mock_event_publisher.assert_not_called()


def test_shutdown():
    """Test shutdown clears all tracked tasks and plans"""
    mock_plan_executor = Mock()
    executor = TaskExecutor(plan_executor=mock_plan_executor)

    # Add some mock data
    executor._active_tasks["task1"] = Mock()
    executor._active_tasks["task2"] = Mock()
    executor._task_plans["plan1"] = Mock()
    executor._task_plans["plan2"] = Mock()

    # Shutdown
    executor.shutdown()

    # Should have cleared everything
    assert executor._active_tasks == {}
    assert executor._task_plans == {}


if __name__ == "__main__":
    pytest.main([__file__, "-v"])