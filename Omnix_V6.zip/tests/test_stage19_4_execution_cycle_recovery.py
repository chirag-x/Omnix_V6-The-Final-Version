"""
Stage 19.4 — Execution Cycle Recovery Integration Tests

Test suite for verifying recovery scenarios in the ExecutionCycle:
- Observation failure recovery (via external retry)
- Grounding failure recovery (via external retry)
- Action failure recovery (via external retry)
- Verification failure recovery (via internal retries)
- Synchronization failure recovery (via external retry)
- Timeout recovery scenarios
- Cancellation recovery scenarios
"""

import asyncio
import time
from typing import Any, Optional, Dict, List
from unittest.mock import AsyncMock, Mock
import pytest

# Import the execution cycle components
from core.execution import (
    ExecutionCycle,
    ExecutionPolicy,
    ExecutionStep,
    StepAction,
    ExecutionResult,
    ExecutionStatus,
    VerificationExpectation,
    ExpectationKind,
    VerificationResult,
    VerificationStatus,
    DefaultActionExecutor,
    DefaultGroundingProvider,
    DefaultVerificationProvider,
    DefaultSynchronizationProvider,
)
from core.execution.errors import (
    ObservationFailedError,
    GroundingFailedError,
    ActionFailedError,
    VerificationFailedError,
)
from core.execution.sync import SynchronizationResult, SynchronizationStatus, SynchronizationContext

# Import Omnix types for mocking
from vision.perception_contract import (
    PerceptionProvider,
    PerceptionRequest,
    PerceptionResult,
    PerceptionStatus,
    ScreenInfo,
)
from core.grounding.target_resolver import TargetResolver, TargetResolutionResult, TargetResolutionStatus
from core.results import CapabilityResult, CapabilityStatus
from core.orchestration.cancellation import CancellationToken


# ---------------------------------------------------------------------------
# Test Doubles for Recovery Testing
# ---------------------------------------------------------------------------

class FailingPerceptionProvider:
    """Perception provider that fails on specific calls for testing recovery."""

    def __init__(self, fail_on_calls: Optional[List[int]] = None, fail_status: PerceptionStatus = PerceptionStatus.FAILED):
        self.fail_on_calls = fail_on_calls or []
        self.fail_status = fail_status
        self.call_count = 0
        self.last_request: Optional[PerceptionRequest] = None

    async def observe(
        self,
        request: PerceptionRequest,
        cancellation_token: Optional[Any] = None,
    ) -> PerceptionResult:
        self.call_count += 1
        self.last_request = request

        if cancellation_token and getattr(cancellation_token, 'is_cancelled', False):
            return PerceptionResult(
                observation_id="cancelled-obs",
                timestamp=time.time(),
                screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
                status=PerceptionStatus.CANCELLED,
                duration_ms=0.0
            )

        # Fail on specified calls
        if self.call_count in self.fail_on_calls:
            return PerceptionResult(
                observation_id="",
                timestamp=time.time(),
                screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
                status=self.fail_status,
                duration_ms=0.0,
            )

        # Success otherwise
        return PerceptionResult(
            observation_id=f"success-obs-{self.call_count}",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        )

    def get_available_sources(self) -> tuple:
        return ()

    def is_source_available(self, source: Any) -> bool:
        return False

    async def invalidate(self, key: Any = None) -> None:
        pass


class FailingGroundingProvider:
    """Grounding provider that fails on specific calls."""

    def __init__(self, fail_on_calls: Optional[List[int]] = None, fail_status: TargetResolutionStatus = TargetResolutionStatus.NOT_FOUND):
        self.fail_on_calls = fail_on_calls or []
        self.fail_status = fail_status
        self.call_count = 0
        self.last_input: Optional[Any] = None

    def resolve(
        self,
        target_input: Any,
        *,
        screen_width: Optional[int] = None,
        screen_height: Optional[int] = None,
    ) -> TargetResolutionResult:
        self.call_count += 1
        self.last_input = target_input

        # Fail on specified calls
        if self.call_count in self.fail_on_calls:
            return TargetResolutionResult(
                status=self.fail_status,
                target=None,
                reason=str(target_input),
                details={"fake": True},
            )

        # Success otherwise
        return TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),  # Mock target
            reason=str(target_input),
            details={"fake": True},
        )

    def get_available_sources(self) -> tuple:
        return ()


class FailingActionExecutor:
    """Action executor that fails on specific calls."""

    def __init__(self, fail_on_calls: Optional[List[int]] = None, fail_status: CapabilityStatus = CapabilityStatus.FAILED):
        self.fail_on_calls = fail_on_calls or []
        self.fail_status = fail_status
        self.call_count = 0
        self.last_call: Optional[Dict[str, Any]] = None

    async def execute(
        self,
        capability_name: str,
        parameters: Dict[str, Any],
        target: Optional[Any] = None,
        timeout_s: float = 30.0,
        cancellation_token: Optional[Any] = None,
    ) -> CapabilityResult:
        self.call_count += 1
        self.last_call = {
            "capability_name": capability_name,
            "parameters": parameters,
            "target": target,
            "timeout_s": timeout_s,
        }

        # Check for cancellation
        if cancellation_token and getattr(cancellation_token, 'is_cancelled', False):
            return CapabilityResult(
                capability_name=capability_name,
                status=CapabilityStatus.CANCELLED,
                attempted=True,
                executed=False,
                verified=False,
                failed=False,
                duration_ms=0.0,
            )

        # Fail on specified calls
        if self.call_count in self.fail_on_calls:
            return CapabilityResult(
                capability_name=capability_name,
                status=self.fail_status,
                attempted=True,
                executed=False,
                verified=False,
                failed=True,
                duration_ms=0.0,
                details={"error": "Simulated failure"},
            )

        # Success otherwise
        return CapabilityResult(
            capability_name=capability_name,
            status=CapabilityStatus.EXECUTED,
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        )


class FailingVerificationProvider:
    """Verification provider that fails on specific calls."""

    def __init__(self, fail_on_calls: Optional[List[int]] = None, fail_status: VerificationStatus = VerificationStatus.FAILED):
        self.fail_on_calls = fail_on_calls or []
        self.fail_status = fail_status
        self.call_count = 0
        self.last_expectation: Optional[Any] = None
        self.last_observation: Optional[Any] = None

    async def verify(
        self,
        expectation: VerificationExpectation,
        observation: PerceptionResult,
        cancellation_token: Optional[Any] = None,
    ) -> VerificationResult:
        self.call_count += 1
        self.last_expectation = expectation
        self.last_observation = observation

        # Check for cancellation
        if cancellation_token and getattr(cancellation_token, 'is_cancelled', False):
            return VerificationResult(
                verification_id="cancelled-verif",
                status=VerificationStatus.CANCELLED,
                success=False,
                evidence=observation,
                observation_id=observation.observation_id,
                elapsed_ms=0.0,
                reason="Verification cancelled",
                attempt=1,
            )

        # Fail on specified calls
        if self.call_count in self.fail_on_calls:
            return VerificationResult(
                verification_id=f"fake-verif-{self.call_count}",
                status=self.fail_status,
                success=False,
                evidence=observation,
                observation_id=observation.observation_id,
                elapsed_ms=5.0,
                reason="fake verification failure",
                attempt=1,
            )

        # Success otherwise
        return VerificationResult(
            verification_id=f"fake-verif-{self.call_count}",
            status=VerificationStatus.SUCCESS,
            success=True,
            evidence=observation,
            observation_id=observation.observation_id,
            elapsed_ms=5.0,
            reason="fake verification success",
            attempt=1,
        )


class SequencingVerificationProvider:
    """Verification provider that returns a predefined sequence of results."""

    def __init__(self, sequence: List[tuple[VerificationStatus, bool]]):
        """
        Args:
            sequence: List of (status, success) tuples to return in order.
                      After the sequence is exhausted, returns (SUCCESS, True).
        """
        self.sequence = sequence
        self.call_count = 0
        self.last_expectation: Optional[Any] = None
        self.last_observation: Optional[Any] = None

    async def verify(
        self,
        expectation: VerificationExpectation,
        observation: PerceptionResult,
        cancellation_token: Optional[Any] = None,
    ) -> VerificationResult:
        self.call_count += 1
        self.last_expectation = expectation
        self.last_observation = observation

        # Check for cancellation
        if cancellation_token and getattr(cancellation_token, 'is_cancelled', False):
            return VerificationResult(
                verification_id="cancelled-verif",
                status=VerificationStatus.CANCELLED,
                success=False,
                evidence=observation,
                observation_id=observation.observation_id,
                elapsed_ms=0.0,
                reason="Verification cancelled",
                attempt=1,
            )

        # Return the next in sequence, or default to success after sequence exhausted
        if self.call_count <= len(self.sequence):
            status, success = self.sequence[self.call_count - 1]
        else:
            status, success = VerificationStatus.SUCCESS, True

        return VerificationResult(
            verification_id=f"seq-verif-{self.call_count}",
            status=status,
            success=success,
            evidence=observation,
            observation_id=observation.observation_id,
            elapsed_ms=5.0,
            reason=f"sequenced verification: {status.value}",
            attempt=self.call_count,
        )


class FailingSynchronizationProvider:
    """Synchronization provider that fails on specific calls."""

    def __init__(self, fail_on_calls: Optional[List[int]] = None, fail_status: SynchronizationStatus = SynchronizationStatus.ERROR):
        self.fail_on_calls = fail_on_calls or []
        self.fail_status = fail_status
        self.call_count = 0
        self.last_context: Optional[Any] = None
        self.last_timeout_s: float = 0.0
        self.last_poll_interval_s: float = 0.0
        self.last_cancellation_token: Optional[Any] = None

    @property
    def name(self) -> str:
        return "failing-synchronization-provider"

    async def wait_until_settled(
        self,
        context: SynchronizationContext,
        *,
        timeout_s: float = 5.0,
        poll_interval_s: float = 0.05,
        cancellation_token: Optional[Any] = None,
    ) -> SynchronizationResult:
        self.call_count += 1
        self.last_context = context
        self.last_timeout_s = timeout_s
        self.last_poll_interval_s = poll_interval_s
        self.last_cancellation_token = cancellation_token

        # Check for cancellation
        if cancellation_token and getattr(cancellation_token, 'is_cancelled', False):
            return SynchronizationResult(
                status=SynchronizationStatus.CANCELLED,
                settled=False,
                elapsed_ms=0.0,
                reason="Cancelled during sync",
                poll_count=0,
            )

        # Fail on specified calls
        if self.call_count in self.fail_on_calls:
            return SynchronizationResult(
                status=self.fail_status,
                settled=False,
                observation_id=f"sync-obs-{self.call_count}",
                confidence=0.0,
                elapsed_ms=10.0,
                reason=f"Fake sync failure: {self.fail_status.value}",
                poll_count=1,
            )

        # Success otherwise (SETTLED)
        return SynchronizationResult(
            status=SynchronizationStatus.SETTLED,
            settled=True,
            observation_id=f"sync-obs-{self.call_count}",
            confidence=1.0,
            elapsed_ms=10.0,
            reason=f"Fake sync success: {SynchronizationStatus.SETTLED.value}",
            poll_count=1,
        )


# ---------------------------------------------------------------------------
# Recovery Test Scenarios
# ---------------------------------------------------------------------------

class TestExecutionCycleObservationRecovery:
    """Test recovery from observation failures via external retry."""

    @pytest.mark.asyncio
    async def test_observation_failure_then_success_external_retry(self):
        """Test that observation failure on first execution succeeds on second execution (external retry)."""
        # Fail first call, succeed on second
        perception = FailingPerceptionProvider(fail_on_calls=[1])
        grounding = Mock()
        action = Mock()
        verification = Mock()

        # Configure mocks to return success when called
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        verification.verify = AsyncMock(return_value=VerificationResult(
            status=VerificationStatus.SUCCESS,
            success=True,
            verification_id="test",
            evidence=None,
            observation_id="test-obs",
            elapsed_ms=5.0,
            reason="test",
            attempt=1,
        ))

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            policy=ExecutionPolicy(observation_timeout_s=1.0, enable_recovery=False),
        )

        step = ExecutionStep(
            step_id="test-recovery-1",
            description="Test observation recovery",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
        )

        # First execution: perception fails on call 1 -> observation should fail
        result1 = await cycle.execute(step)
        assert result1.status == ExecutionStatus.OBSERVATION_FAILED
        assert perception.call_count == 1  # Only one call made

        # Second execution: perception succeeds on call 2 (since we use the same provider, call_count is now 2)
        result2 = await cycle.execute(step)
        assert result2.status == ExecutionStatus.SUCCESS
        assert perception.call_count == 2  # Second call succeeded


class TestExecutionCycleGroundingRecovery:
    """Test recovery from grounding failures via external retry."""

    @pytest.mark.asyncio
    async def test_grounding_failure_then_success_external_retry(self):
        """Test that grounding failure on first execution succeeds on second execution (external retry)."""
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        # Fail first call, succeed on second
        grounding = FailingGroundingProvider(fail_on_calls=[1])
        action = Mock()
        verification = Mock()

        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        verification.verify = AsyncMock(return_value=VerificationResult(
            status=VerificationStatus.SUCCESS,
            success=True,
            verification_id="test",
            evidence=None,
            observation_id="test-obs",
            elapsed_ms=5.0,
            reason="test",
            attempt=1,
        ))

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            policy=ExecutionPolicy(enable_recovery=False),
        )

        step = ExecutionStep(
            step_id="test-recovery-2",
            description="Test grounding recovery",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
        )

        # First execution: grounding fails on call 1 -> grounding should fail
        result1 = await cycle.execute(step)
        assert result1.status == ExecutionStatus.GROUNDING_FAILED
        assert grounding.call_count == 1  # Only one call made

        # Second execution: grounding succeeds on call 2
        result2 = await cycle.execute(step)
        assert result2.status == ExecutionStatus.SUCCESS
        assert grounding.call_count == 2  # Second call succeeded


class TestExecutionCycleActionRecovery:
    """Test recovery from action failures via external retry."""

    @pytest.mark.asyncio
    async def test_action_failure_then_success_external_retry(self):
        """Test that action failure on first execution succeeds on second execution (external retry)."""
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        # Fail first call, succeed on second
        action = FailingActionExecutor(fail_on_calls=[1])
        verification = Mock()

        verification.verify = AsyncMock(return_value=VerificationResult(
            status=VerificationStatus.SUCCESS,
            success=True,
            verification_id="test",
            evidence=None,
            observation_id="test-obs",
            elapsed_ms=5.0,
            reason="test",
            attempt=1,
        ))

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            policy=ExecutionPolicy(enable_recovery=False),
        )

        step = ExecutionStep(
            step_id="test-recovery-3",
            description="Test action recovery",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
        )

        # First execution: action fails on call 1 -> action should fail
        result1 = await cycle.execute(step)
        assert result1.status == ExecutionStatus.ACTION_FAILED
        assert action.call_count == 1  # Only one call made

        # Second execution: action succeeds on call 2
        result2 = await cycle.execute(step)
        assert result2.status == ExecutionStatus.SUCCESS
        assert action.call_count == 2  # Second call succeeded


class TestExecutionCycleVerificationRecovery:
    """Test recovery from verification failures via internal retries."""

    @pytest.mark.asyncio
    async def test_verification_inconclusive_then_success_internal_retry(self):
        """Test that verification fails first few attempts (INCONCLUSIVE) then succeeds within one execution (internal retries)."""
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action = Mock()
        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        # Fail first 2 verification attempts with INCONCLUSIVE, succeed on the third
        verification = SequencingVerificationProvider([
            (VerificationStatus.INCONCLUSIVE, False),
            (VerificationStatus.INCONCLUSIVE, False),
            (VerificationStatus.SUCCESS, True)
        ])

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            policy=ExecutionPolicy(verification_max_attempts=3, enable_recovery=False),  # Allow up to 3 attempts
        )

        step = ExecutionStep(
            step_id="test-recovery-4",
            description="Test verification recovery",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
            expectation=VerificationExpectation.target_visible("Test Target"),
        )

        # Execute - should succeed because verification retries internally and succeeds on third attempt
        result = await cycle.execute(step)

        # Should succeed because verification succeeded on third internal attempt
        assert result.status == ExecutionStatus.SUCCESS
        assert verification.call_count == 3  # Failed first two, succeeded third

    @pytest.mark.asyncio
    async def test_verification_fails_all_internal_attempts(self):
        """Test that verification fails when all internal INCONCLUSIVE attempts are exhausted."""
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action = Mock()
        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        # Fail all verification attempts with INCONCLUSIVE (will be retried until max attempts)
        verification = SequencingVerificationProvider([
            (VerificationStatus.INCONCLUSIVE, False),
            (VerificationStatus.INCONCLUSIVE, False),
            (VerificationStatus.INCONCLUSIVE, False),
        ])

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            policy=ExecutionPolicy(verification_max_attempts=3, enable_recovery=False),  # Allow only 3 attempts
        )

        step = ExecutionStep(
            step_id="test-verification-fail-all",
            description="Test verification fails all attempts",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
            expectation=VerificationExpectation.target_visible("Test Target"),
        )

        # Execute - should fail because verification fails all internal attempts (INCONCLUSIVE treated as failure)
        result = await cycle.execute(step)

        # Should fail because verification failed after 3 attempts (INCONCLUSIVE treated as failure for cycle)
        assert result.status == ExecutionStatus.VERIFICATION_FAILED
        assert verification.call_count == 3  # Only 3 attempts made (as per max_attempts)

    @pytest.mark.asyncio
    async def test_verification_fails_immediately_no_retry(self):
        """Test that verification fails immediately on FAILED (no retry for FAILED status)."""
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action = Mock()
        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        # Fail on first attempt with FAILED status (no retry)
        verification = SequencingVerificationProvider([
            (VerificationStatus.FAILED, False),
        ])

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            policy=ExecutionPolicy(verification_max_attempts=3, enable_recovery=False),  # Allow up to 3 attempts
        )

        step = ExecutionStep(
            step_id="test-verification-fail-immediate",
            description="Test verification fails immediately",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
            expectation=VerificationExpectation.target_visible("Test Target"),
        )

        # Execute - should fail immediately because FAILED is not retried
        result = await cycle.execute(step)

        # Should fail immediately on first attempt
        assert result.status == ExecutionStatus.VERIFICATION_FAILED
        assert verification.call_count == 1  # Only one attempt made (no retry for FAILED)


class TestExecutionCycleSynchronizationRecovery:
    """Test recovery from synchronization failures via external retry."""

    @pytest.mark.asyncio
    async def test_synchronization_failure_then_success_external_retry(self):
        """Test that synchronization failure on first execution succeeds on second execution (external retry)."""
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action = Mock()
        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        verification = Mock()
        verification.verify = AsyncMock(return_value=VerificationResult(
            status=VerificationStatus.SUCCESS,
            success=True,
            verification_id="test",
            evidence=None,
            observation_id="test-obs",
            elapsed_ms=5.0,
            reason="test",
            attempt=1,
        ))

        # Fail first call, succeed on second
        sync_provider = FailingSynchronizationProvider(fail_on_calls=[1])

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            synchronization_provider=sync_provider,
            policy=ExecutionPolicy(
                enable_synchronization=True,
                require_settlement=True,
                synchronization_timeout_s=1.0,
                enable_recovery=False,
            ),
        )

        step = ExecutionStep(
            step_id="test-recovery-5",
            description="Test synchronization recovery",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
        )

        # First execution: synchronization fails on call 1 -> synchronization should fail
        result1 = await cycle.execute(step)
        assert result1.status == ExecutionStatus.SYNCHRONIZATION_FAILED
        assert sync_provider.call_count == 1  # Only one call made

        # Second execution: synchronization succeeds on call 2
        result2 = await cycle.execute(step)
        assert result2.status == ExecutionStatus.SUCCESS
        assert sync_provider.call_count == 2  # Second call succeeded


class TestExecutionCycleTimeoutRecovery:
    """Test recovery from timeout scenarios."""

    @pytest.mark.asyncio
    async def test_observation_timeout_then_success_external_retry(self):
        """Test recovery from observation timeout via external retry."""
        call_count = 0

        async def observe_with_timeout_then_success(*args, **kwargs):
            nonlocal call_count
            call_count += 1

            if call_count == 1:
                # First call times out
                await asyncio.sleep(0.2)  # Longer than timeout
                return PerceptionResult(
                    observation_id="",
                    timestamp=time.time(),
                    screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
                    status=PerceptionStatus.TIMEOUT,
                    duration_ms=200.0,
                )
            else:
                # Second call succeeds
                return PerceptionResult(
                    observation_id=f"success-obs-{call_count}",
                    timestamp=time.time(),
                    screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
                    status=PerceptionStatus.SUCCESS,
                    duration_ms=10.0,
                )

        perception = Mock()
        perception.observe = AsyncMock(side_effect=observe_with_timeout_then_success)

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action = Mock()
        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        verification = Mock()
        verification.verify = AsyncMock(return_value=VerificationResult(
            status=VerificationStatus.SUCCESS,
            success=True,
            verification_id="test",
            evidence=None,
            observation_id="test-obs",
            elapsed_ms=5.0,
            reason="test",
            attempt=1,
        ))

        # Short timeout to trigger timeout on first attempt
        policy = ExecutionPolicy(observation_timeout_s=0.1)

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
            policy=policy,
        )

        step = ExecutionStep(
            step_id="test-timeout-recovery-1",
            description="Test timeout recovery",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
        )

        # First execution: observation times out -> timeout failure
        result1 = await cycle.execute(step)
        assert result1.status == ExecutionStatus.TIMEOUT
        assert call_count == 1  # Only one call made (timed out)

        # Second execution: observation succeeds
        result2 = await cycle.execute(step)
        assert result2.status == ExecutionStatus.SUCCESS
        assert call_count == 2  # Second call succeeded


class TestExecutionCycleCancellationRecovery:
    """Test recovery from cancellation scenarios."""

    @pytest.mark.asyncio
    async def test_cancellation_during_execution_then_success(self):
        """Test that execution can succeed after being cancelled."""
        # This test verifies that the cycle can be executed again after cancellation
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action = Mock()
        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        verification = Mock()
        verification.verify = AsyncMock(return_value=VerificationResult(
            status=VerificationStatus.SUCCESS,
            success=True,
            verification_id="test",
            evidence=None,
            observation_id="test-obs",
            elapsed_ms=5.0,
            reason="test",
            attempt=1,
        ))

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
        )

        step = ExecutionStep(
            step_id="test-cancel-recovery-1",
            description="Test cancellation recovery",
            action=StepAction.CLICK,
            capability_name="test.capability",
            target_query="Test Target",
        )

        # First execution with cancellation
        cancellation_token = CancellationToken()
        cancellation_token.cancel()  # Pre-cancelled

        result1 = await cycle.execute(step, cancellation_token=cancellation_token)
        assert result1.status == ExecutionStatus.CANCELLED

        # Second execution without cancellation should succeed
        result2 = await cycle.execute(step)
        assert result2.status == ExecutionStatus.SUCCESS


if __name__ == "__main__":
    # Run a simple test to verify basic functionality
    import asyncio

    async def simple_test():
        perception = Mock()
        perception.observe = AsyncMock(return_value=PerceptionResult(
            observation_id="test-obs",
            timestamp=time.time(),
            screen=ScreenInfo(width=1920, height=1080, dpi_scale_x=1.0, dpi_scale_y=1.0),
            status=PerceptionStatus.SUCCESS,
            duration_ms=10.0,
        ))

        grounding = Mock()
        grounding.resolve.return_value = TargetResolutionResult(
            status=TargetResolutionStatus.RESOLVED,
            target=Mock(),
            reason="test",
            details={}
        )

        action = Mock()
        action.execute = AsyncMock(return_value=CapabilityResult(
            status=CapabilityStatus.EXECUTED,
            capability_name="test",
            attempted=True,
            executed=True,
            verified=False,
            failed=False,
            duration_ms=10.0,
        ))

        verification = Mock()
        verification.verify = AsyncMock(return_value=VerificationResult(
            status=VerificationStatus.SUCCESS,
            success=True,
            verification_id="test",
            evidence=None,
            observation_id="test-obs",
            elapsed_ms=5.0,
            reason="test",
            attempt=1,
        ))

        cycle = ExecutionCycle(
            perception_provider=perception,
            target_resolver=grounding,
            action_executor=action,
            verification_provider=verification,
        )

        step = ExecutionStep(
            step_id="simple-test",
            description="Simple test",
            action=StepAction.CLICK,
        )

        result = await cycle.execute(step)
        print(f"Simple test result: {result.status}")
        assert result.status == ExecutionStatus.SUCCESS
        print("✓ Basic execution cycle test passed")

    asyncio.run(simple_test())
    print("All basic tests passed!")